import controller.Controller;
import controller.ControllerImpl;
import model.User;
import model.UserImpl;
import view.View;
import view.ViewImpl;

import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;


import static org.junit.Assert.assertEquals;

/**
 * A JUnit test class for the ControllerImpl class.
 */
public class ControllerImplTest {
  private Controller c;
  private InputStream in;
  private ByteArrayOutputStream bytes;
  private User user;
  private View view;

  @Before
  public void setUp() {

    bytes = new ByteArrayOutputStream();
    PrintStream out = new PrintStream(bytes);
    view = new ViewImpl(out);

    user = new UserImpl();
  }

  @Test
  public void display1Test() {
    in = new ByteArrayInputStream("".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display1();
    String output = bytes.toString();
    String message = "Hi, Welcome to your portfolio\n";
    assertEquals(message, output);
  }

  @Test
  public void createSinglePortfolioTest1() {
    in = new ByteArrayInputStream("1 p1 goog 10 n 2 p1 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 10]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void createSinglePortfolioTest2() {
    in = new ByteArrayInputStream("1 p1 goog 10 y amzn 20 n 2 p1 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 10, amzn 20]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidPortfolioNameTest1() {
    in = new ByteArrayInputStream(("1 p1 goog 10 n 2 p2 2 p1 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter a valid Portfolio Name\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 10]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void createTwoPortfoliosTest1() {
    in = new ByteArrayInputStream(("1 p1 goog 10 n " +
            "1 p2 msft 20 y amzn 30 y v 40 n 2 p1 2 p2 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 10]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[v 40, msft 20, amzn 30]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void enterSameStockTest1() {
    in = new ByteArrayInputStream("1 p1 goog 10 y goog 10 n 2 p1 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 20]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void enterSameStockTest3() {
    in = new ByteArrayInputStream("1 p1 goog 10 y amzn 40 y goog 10 n 2 p1 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 20, amzn 40]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void enterSameStockTest4() {
    in = new ByteArrayInputStream(("1 p1 goog 10 y amzn 40 y goog 10 n " +
            "1 p2 msft 2 y v 6 y msft 2 y amzn 20 n 2 p1 2 p2 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 20, amzn 40]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[v 6, msft 4, amzn 20]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void enterSameStockTest2() {
    in = new ByteArrayInputStream("1 p1 goog 10 y goog 10 y goog 10 n 2 p1 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 30]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidTickerTest1() {
    in = new ByteArrayInputStream("1 p1 iedjqoij 10 goog 10 n 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Invalid ticker entered\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidTickerTest2() {
    in = new ByteArrayInputStream("1 p1 ioj21ioj@!*#iniew 10 goog 10 n 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Invalid ticker entered\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidTickerTest3() {
    in = new ByteArrayInputStream("1 p1 123294 10 goog 10 n 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Invalid ticker entered\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidNoOfSharesTest1() {
    in = new ByteArrayInputStream("1 p1 goog -10 goog 10 n 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Enter valid number of shares\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidNoOfSharesTest4() {
    in = new ByteArrayInputStream("1 p1 goog 1.5 amzn 10 n 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Invalid user input entered.\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidNoOfSharesTest2() {
    in = new ByteArrayInputStream("1 p1 goog 0 goog 10 n 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Enter valid number of shares\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidNoOfSharesTest3() {
    in = new ByteArrayInputStream("1 p1 goog -29 goog 10 n 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Enter valid number of shares\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidTickerNoOfSharesTest1() {
    in = new ByteArrayInputStream("1 p1 ijiweo -17 goog 10 n 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Invalid ticker entered\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidTickerNoOfSharesTest2() {
    in = new ByteArrayInputStream("1 p1 ijiweo 0 goog 10 n 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Invalid ticker entered\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidTickerNoOfSharesTest3() {
    in = new ByteArrayInputStream("1 p1 ijiweo -87 goog 10 n 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Invalid ticker entered\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void totalPortfolioValueTest1() {
    in = new ByteArrayInputStream("1 p1 goog 10 y msft 20 n 3 p1 2022-01-01 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "\nTicker [unit_Stock_Price, no_Of_Shares, stock_Value]\n" +
            "goog [2893.59, 10.0, 28935.9]\n" +
            "msft [336.32, 20.0, 6726.4004]\n" +
            "The Total Value is : 35662.3\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void totalPortfolioValueTest2() {
    in = new ByteArrayInputStream(("1 p1 goog 10 y msft 20 n 1 p2 amzn 30 y v 40 n " +
            "3 p1 2022-01-01 3 p2 2022-01-01 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "\nTicker [unit_Stock_Price, no_Of_Shares, stock_Value]\n" +
            "goog [2893.59, 10.0, 28935.9]\n" +
            "msft [336.32, 20.0, 6726.4004]\n" +
            "The Total Value is : 35662.3\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "\nTicker [unit_Stock_Price, no_Of_Shares, stock_Value]\n" +
            "v [216.71, 40.0, 8668.4]\n" +
            "amzn [3334.34, 30.0, 100030.2]\n" +
            "The Total Value is : 108698.6\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidDateTest1() {
    in = new ByteArrayInputStream("1 p1 goog 10 y msft 20 n 3 p1 1234-01-01 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "Invalid date entered.\n" +
            "\nPlease Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidDateFormatTest1() {
    in = new ByteArrayInputStream("1 p1 goog 10 y msft 20 n 3 p1 2022/01/01 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "Invalid date format. Please enter date in yyyy-mm-dd format.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidDateFormatTest2() {
    in = new ByteArrayInputStream("1 p1 goog 10 y msft 20 n 3 p1 2022.01.01 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "Invalid date format. Please enter date in yyyy-mm-dd format.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void savePortfolioTest1() {
    in = new ByteArrayInputStream("1 p1 goog 10 y msft 20 y amzn 30 n 4 p1 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p1 saved.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void savePortfolioTest2() {
    in = new ByteArrayInputStream(("1 p1 goog 10 y msft 20 y amzn 30 n " +
            "1 p2 v 40 y hon 50 n 4 p1 4 p2 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p1 saved.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p2 saved.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void loadPortfolioTest1() {
    in = new ByteArrayInputStream(("5 p10 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter a valid Portfolio Name\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void saveLoadPortfolioTest1() {
    in = new ByteArrayInputStream(("1 p1 goog 10 y msft 20 y amzn 30 n " +
            "4 p1 5 p1 2 p1 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p1 saved.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p1 successfully loaded.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 10, msft 20, amzn 30]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void saveLoadPortfolioValueTest() {
    in = new ByteArrayInputStream(("1 p1 goog 10 y msft 20 y amzn 30 n " +
            "4 p1 5 p1 2 p1 3 p1 2020-01-01 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p1 saved.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p1 successfully loaded.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 10, msft 20, amzn 30]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "\n" +
            "Ticker [unit_Stock_Price, no_Of_Shares, stock_Value]\n" +
            "goog [1337.02, 10.0, 13370.2]\n" +
            "msft [157.7, 20.0, 3154.0]\n" +
            "amzn [1847.84, 30.0, 55435.2]\n" +
            "The Total Value is : 71959.4\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void saveLoadPortfolioTest2() {
    in = new ByteArrayInputStream(("1 p1 goog 10 y msft 20 y amzn 30 n 1 p2 v 40 y adbe 50 n " +
            "4 p1 4 p2 5 p1 5 p2 2 p1 2 p2 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p1 saved.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p2 saved.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p1 successfully loaded.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Portfolio p2 successfully loaded.\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[goog 10, msft 20, amzn 30]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "[v 40, adbe 50]\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void savePortfolioExitTest1() {
    in = new ByteArrayInputStream("1 p1 goog 10 y msft 20 y amzn 30 n 6 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Portfolio p1 saved.\n";
    assertEquals(message, output);
  }

  @Test
  public void savePortfolioExitTest2() {
    in = new ByteArrayInputStream(("1 p1 goog 10 y msft 20 y amzn 30 n " +
            "1 p2 v 40 y hon 50 n 6 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Portfolio p1 saved.\n" +
            "Portfolio p2 saved.\n";
    assertEquals(message, output);
  }

  @Test
  public void savePortfolioExitTwelveCompanies() {
    in = new ByteArrayInputStream(("1 p1 goog 10 y msft 20 y amzn 30 y aapl 10 y bac 20 y bmy " +
            "30 y cvx 10 y dhr 20 y hd 30 y dis 10 y cost 20 y pg 30 n " +
            "1 p2 v 40 y hon 50 n 6 7").getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Portfolio p1 saved.\n" +
            "Portfolio p2 saved.\n";
    assertEquals(message, output);
  }

  @Test
  public void totalPortfolioValueTestSaturday() {
    in = new ByteArrayInputStream("1 p1 goog 10 y msft 20 n 3 p1 2022-10-22 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "\nTicker [unit_Stock_Price, no_Of_Shares, stock_Value]\n" +
            "goog [101.48, 10.0, 1014.80005]\n" +
            "msft [242.12, 20.0, 4842.4]\n" +
            "The Total Value is : 5857.2\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void totalPortfolioValueTestSunday() {
    in = new ByteArrayInputStream("1 p1 goog 10 y msft 20 n 3 p1 2022-10-23 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "\nTicker [unit_Stock_Price, no_Of_Shares, stock_Value]\n" +
            "goog [101.48, 10.0, 1014.80005]\n" +
            "msft [242.12, 20.0, 4842.4]\n" +
            "The Total Value is : 5857.2\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidDatePastDate() {
    in = new ByteArrayInputStream("1 p1 goog 10 y msft 20 n 3 p1 1930-01-01 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "Invalid date entered.\n" +
            "\nPlease Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }

  @Test
  public void invalidDateFuture() {
    in = new ByteArrayInputStream("1 p1 goog 10 y msft 20 n 3 p1 2025-01-01 7".getBytes());
    c = new ControllerImpl(user, view, in);
    c.display2();
    String output = bytes.toString();
    String message = "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "Enter Stock ticker and number of shares\n" +
            "Do you want to continue adding Stocks?\n" +
            "\n" +
            "Please Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n" +
            "Enter Portfolio name\n" +
            "Enter the date in format yyyy-mm-dd.\n" +
            "Invalid date entered.\n" +
            "\nPlease Enter your option\n" +
            "1.) Add a new Portfolio\n" +
            "2.) View a Portfolio\n" +
            "3.) Show the total value of a Portfolio\n" +
            "4.) Save a Portfolio\n" +
            "5.) Load a Portfolio\n" +
            "6.) Exit the program\n";
    assertEquals(message, output);
  }
}


