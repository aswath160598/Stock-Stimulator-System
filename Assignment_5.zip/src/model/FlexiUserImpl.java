package model;

import org.xml.sax.SAXException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import utilities.FileHandler;
import utilities.GraphDraw;
import utilities.GraphDrawImpl;
import utilities.XMLFileHandler;

import static java.time.temporal.ChronoUnit.DAYS;

/**
 * This class implements the methods of the flexible User interface where all User operations
 * are performed on a Portfolio.
 */
public class FlexiUserImpl extends UserImpl implements FlexiUser {
  private final Map<String, FlexiPortfolio> fPortfolios;
  private float commissionFee;

  public FlexiUserImpl() {
    this.fPortfolios = new HashMap<>();
    this.commissionFee = 1;
  }

  public FlexiUserImpl(Map<String, FlexiPortfolio> fportfolios) {
    this.fPortfolios = fportfolios;
    this.commissionFee = 1;
  }

  @Override
  public void addNewFlexiPortfolio(Map<String, List<List<String>>> p, String name) {
    fPortfolios.put(name, new FlexiPortfolioImpl(p));
  }

  @Override
  public int getNoOfPortfolios() {
    return fPortfolios.size();
  }

  @Override
  public FlexiPortfolio getPortfolio(String portfolioName) {
    return this.fPortfolios.get(portfolioName);
  }

  @Override
  public String toString() {
    return this.fPortfolios.toString();
  }

  @Override
  public float getFlexiPortfolioValue(String portfolioName, String date)
          throws ParseException {
    FlexiPortfolio flexiPortfolio = getPortfolio(portfolioName);
    GetStockValueAPIImpl getVal = new GetStockValueAPIImpl();
    String[] buyDate = date.split("-");
    LocalDate buyDateL = LocalDate.of(Integer.parseInt(buyDate[0]),
            Integer.parseInt(buyDate[1]), Integer.parseInt(buyDate[2]));
    Map<String, Float> composition = flexiPortfolio.getComposition(buyDateL);
    float stockValue;
    float sum = 0;
    for (Map.Entry<String, Float> mapElement : composition.entrySet()) {
      String key = mapElement.getKey();
      float noOfShares = mapElement.getValue();
      stockValue = getVal.getStockPrice(key, date);
      sum = sum + (stockValue * noOfShares);
    }
    return sum;
  }

  @Override
  public Boolean checkPortfolioExists(String name) {
    return fPortfolios.containsKey(name);
  }

  @Override
  public List<String> getAllPortfolioNames() {
    List<String> s = new ArrayList<>();
    for (Map.Entry<String, FlexiPortfolio> mapElement : fPortfolios.entrySet()) {
      s.add(mapElement.getKey());
    }
    return s;
  }

  @Override
  public Boolean checkPortfolioFileExists(String name) {
    Path path = Paths.get(name + ".xml");
    return Files.exists(path);
  }

  @Override
  public void addStockToExistingPortfolio(FlexiStocks s, String portfolioName) {
    getPortfolio(portfolioName).addStock(s);
  }

  @Override
  public float calculateCostBasis(String portfolioName, String date, float fee)
          throws ParseException {
    if (fee <= 0) {
      throw new IllegalArgumentException("Commission fees cannot be less than or equal to zero");
    }
    commissionFee = fee;
    if (checkPortfolioExists(portfolioName)) {
      FlexiPortfolio fp = getPortfolio(portfolioName);
      return fp.calculatePortfolioCostBasis(commissionFee, date);
    } else {
      return 0;
    }
  }

  @Override
  public void saveFlexiPortfolio(String portfolioName) throws ParserConfigurationException,
          FileNotFoundException, TransformerException {
    FlexiPortfolio fp = getPortfolio(portfolioName);

    FileHandler fh = new XMLFileHandler();
    fh.savePortfolio(fp, portfolioName);

  }

  @Override
  public void loadFlexiPortfolio(String portfolioName) throws IllegalArgumentException,
          ParserConfigurationException, IOException, SAXException {
    FileHandler fh = new XMLFileHandler();
    Map<String, List<List<String>>> h = fh.loadPortfolio(portfolioName);
    addNewFlexiPortfolio(h, portfolioName);
  }

  private float getValHelper(LocalDate current, FlexiPortfolio flexiPortfolio,
                             GetStockValueAPI getVal, Map<String, Map<String, Float>> c) {
    float sum = 0;

    LocalDate cDate = current;
    sum = 0;
    Map<String, Float> comp = flexiPortfolio.getComposition(current);
    for (Map.Entry<String, Float> mapElement : comp.entrySet()) {

      String ticker = mapElement.getKey();
      if (!c.containsKey(ticker)) {
        c.put(ticker, getVal.getStockString(ticker));
      }

      Map<String, Float> v = c.get(ticker);

      while (!v.containsKey(cDate.toString())) {
        cDate = cDate.minusDays(1);
      }

      sum += v.get(cDate.toString()) * comp.get(ticker);

    }

    return sum;
  }

  @Override
  public StringBuilder drawGraph(String portfolioName, String startDate, String endDate) throws
          ParseException {
    StringBuilder str = new StringBuilder();
    StringBuilder str1 = new StringBuilder();
    GraphDraw gr = new GraphDrawImpl();
    String[] sDateString = startDate.split("-");
    String[] eDateString = endDate.split("-");
    float sum = 0;
    List<String> timeStamp = new ArrayList<>();

    Map<String, Map<String, Float>> c = new HashMap<>();
    GetStockValueAPI getVal = new GetStockValueAPIImpl();

    FlexiPortfolio flexiPortfolio = getPortfolio(portfolioName);

    LocalDate sDate1 = LocalDate.of(Integer.parseInt(sDateString[0]),
            Integer.parseInt(sDateString[1]), Integer.parseInt(sDateString[2]));
    LocalDate eDate1 = LocalDate.of(Integer.parseInt(eDateString[0]),
            Integer.parseInt(eDateString[1]), Integer.parseInt(eDateString[2]));

    if (eDate1.isBefore(sDate1) || eDate1.equals(sDate1)) {
      throw new IllegalArgumentException("End date cannot be before start date " +
              "or equal to start date.");
    }

    LocalDate current = sDate1;
    long daysBetween = DAYS.between(sDate1, eDate1);
    List<Float> values = new ArrayList<>();
    if (daysBetween > 0 && daysBetween < 31) {
      while (current.isBefore(eDate1) || current.isEqual(eDate1)) {
        timeStamp.add(current.toString());
        sum = getValHelper(current, flexiPortfolio, getVal, c);
        values.add(sum);
        current = current.plusDays(1);
      }
    } else if (daysBetween > 30 && daysBetween < 60) {
      while (current.isBefore(eDate1.plusDays(2)) || current.isEqual(eDate1)) {
        timeStamp.add(current.toString());
        if (eDate1.isBefore(current)) {
          current = eDate1;
        }
        sum = getValHelper(current, flexiPortfolio, getVal, c);
        values.add(sum);
        current = current.plusDays(2);
      }
    } else if (daysBetween > 59 && daysBetween < 150) {
      while (current.isBefore(eDate1.plusDays((5))) || current.isEqual(eDate1)) {
        timeStamp.add(current.toString());
        if (eDate1.isBefore(current)) {
          current = eDate1;
        }
        sum = getValHelper(current, flexiPortfolio, getVal, c);
        values.add(sum);
        current = current.plusDays(5);
      }
    } else if (daysBetween > 149 && daysBetween < 900) {
      while (current.isBefore(eDate1.plusDays(30))) {
        Month x = current.getMonth();
        String s = String.valueOf(x);
        String sub_str = (s.substring(0, 3));
        String monthYear;
        monthYear = (sub_str + " " + current.getYear());
        LocalDate lastDayOfMonth = LocalDate.parse(current.toString(),
                        DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                .with(TemporalAdjusters.lastDayOfMonth());
        if (eDate1.isBefore(lastDayOfMonth)) {
          lastDayOfMonth = eDate1;
          x = eDate1.getMonth();
          s = String.valueOf(x);
          sub_str = (s.substring(0, 3));
          monthYear = (sub_str + " " + current.getYear());
        }
        if (!timeStamp.contains(monthYear)) {
          timeStamp.add(monthYear);
          sum = getValHelper(lastDayOfMonth, flexiPortfolio, getVal, c);
          values.add(sum);
        }
        current = current.plusDays(32);
      }
    } else if (daysBetween > 899 && daysBetween < 2700) {
      while (current.isBefore(eDate1.plusDays(90))) {
        Month x = current.getMonth();
        String s = String.valueOf(x);
        String sub_str = (s.substring(0, 3));
        String monthYear;
        monthYear = (sub_str + " " + current.getYear());
        LocalDate lastDayOfMonth = LocalDate.parse(current.toString(),
                        DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                .with(TemporalAdjusters.lastDayOfMonth());
        if (eDate1.isBefore(lastDayOfMonth)) {
          lastDayOfMonth = eDate1;
          x = eDate1.getMonth();
          s = String.valueOf(x);
          sub_str = (s.substring(0, 3));
          monthYear = (sub_str + " " + current.getYear());
        }
        if (!timeStamp.contains(monthYear)) {
          timeStamp.add(monthYear);
          sum = getValHelper(lastDayOfMonth, flexiPortfolio, getVal, c);
          values.add(sum);
        }
        current = current.plusDays(90);
      }
    } else if (daysBetween > 2699) {
      while (current.isBefore(eDate1.plusDays(365))) {
        int year = current.getYear();
        LocalDate lastWorkingDay = LocalDate.of(year, 12, 31);
        if (eDate1.isBefore(lastWorkingDay)) {
          lastWorkingDay = eDate1;
        }
        timeStamp.add(lastWorkingDay.toString());
        sum = getValHelper(lastWorkingDay, flexiPortfolio, getVal, c);
        values.add(sum);
        current = current.plusDays(365);
      }
    }
    str.append("\nPerformance of portfolio ")
            .append(portfolioName)
            .append(" from ")
            .append(startDate)
            .append(" to ")
            .append(endDate)
            .append("\n\n");
    str1 = gr.drawGraph(values, timeStamp);
    str.append(str1);
    return str;
  }

}
