package utilities;


import java.util.Collections;
import java.util.List;

import model.FlexiUser;

/**
 * This class represents the graph to be plotted between a particular time range.
 */
public class GraphDrawImpl implements GraphDraw {
  private FlexiUser user;

  @Override
  public StringBuilder drawGraph(List<Float> values, List<String> timeStamp) {
    StringBuilder str = new StringBuilder();
    float min = 0;
    float max;
    max = Collections.max(values);
    min = Collections.min(values);
    if (Math.max(min, max) != 0) {
      double x = max / 50;
      int l = 0;
      x = Math.ceil(x);
      l = (int) x;
      int m = 0;
      for (int i = 0; i < values.size(); i++) {
        str.append(timeStamp.get(i)).append("  ");
        m = values.get(i).intValue() / l;
        for (int j = 0; j < m; j++) {
          str.append("*");
        }
        str.append("\n");
      }
      str.append("\nScale: * = $").append(x);
    } else {
      throw new IllegalArgumentException("No transactions found in the given period.");
    }
    return str;
  }
}


