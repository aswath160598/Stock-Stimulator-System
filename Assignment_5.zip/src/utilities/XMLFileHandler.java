package utilities;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import model.FlexiPortfolio;
import model.FlexiPortfolioImpl;
import model.FlexiStocks;
import model.FlexiStocksImpl;
import model.TickerValidator;
import model.TickerValidatorImpl;

/**
 * This class implements all the methods of the file handler interface which consist of saving a
 * file, loading a file.
 */
public class XMLFileHandler implements FileHandler {

  @Override
  public void savePortfolio(FlexiPortfolio fp, String portfolioName) throws
          ParserConfigurationException, FileNotFoundException, TransformerException {
    FlexiStocks fStocks;
    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

    Document doc = docBuilder.newDocument();
    Element rootElement = doc.createElement("Portfolio");
    rootElement.setAttribute("type", "Flexible");
    doc.appendChild(rootElement);
    int x = 0;


    List<FlexiStocks> stockList = new ArrayList<>();
    for (int i = 0; i < fp.size(); i++) {
      stockList.add(fp.getAt(i));
    }

    Comparator<FlexiStocks> comparatorAsc = Comparator.comparing(FlexiStocks::getBuyDate);
    stockList.sort(comparatorAsc);


    for (int i = 0; i < fp.size(); i++) {
      fStocks = stockList.get(i);
      String tickerSymbol = fStocks.getTicker();
      float noOfShares = fStocks.getNoOfShares();
      String date = fStocks.getBuyDate().toString();
      String s = fStocks.getStatus();
      Element stock = doc.createElement("Stock");
      rootElement.appendChild(stock);
      stock.setAttribute("id", String.valueOf(x));
      x++;
      Element ticker = doc.createElement("Ticker");
      ticker.setTextContent(tickerSymbol);
      stock.appendChild(ticker);

      Element noOfStocks = doc.createElement("NoOfStocks");
      noOfStocks.setTextContent(String.valueOf((int) noOfShares));
      stock.appendChild(noOfStocks);

      Element stockDate = doc.createElement("TransactionDate");
      stockDate.setTextContent(date);
      stock.appendChild(stockDate);

      Element status = doc.createElement("Status");
      status.setTextContent(s);
      stock.appendChild(status);
    }
    FileOutputStream output = new FileOutputStream(portfolioName + "_flexible" + ".xml");
    writeXml(doc, output);
  }

  private void writeXml(Document doc, OutputStream output)
          throws TransformerException {

    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    DOMSource source = new DOMSource(doc);
    StreamResult result = new StreamResult(output);
    transformer.transform(source, result);
  }

  @Override
  public Map<String, List<List<String>>> loadPortfolio(String portfolioName) throws
          IllegalArgumentException, ParserConfigurationException, IOException, SAXException {
    TickerValidator tv = new TickerValidatorImpl("stock_master_file.csv");
    tv.readFile();
    Map<String, List<List<String>>> h = new HashMap<>();
    File file = new File(portfolioName + "_flexible" + ".xml");
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    Document doc = db.parse(file);
    doc.getDocumentElement().normalize();
    NodeList nodeList = doc.getElementsByTagName("Stock");

    FlexiPortfolio p = new FlexiPortfolioImpl();
    FlexiStocksImpl s;
    String[] bd;

    for (int itr = 0; itr < nodeList.getLength(); itr++) {
      Node node = nodeList.item(itr);
      if (node.getNodeType() == Node.ELEMENT_NODE) {
        Element eElement = (Element) node;
        String ticker = eElement.getElementsByTagName("Ticker").item(0).getTextContent();
        String noOfStocks = eElement.getElementsByTagName("NoOfStocks")
                .item(0).getTextContent();
        String dateTransaction = eElement.getElementsByTagName("TransactionDate")
                .item(0).getTextContent();
        String status = eElement.getElementsByTagName("Status")
                .item(0).getTextContent();

        if (!(status.equals("b") || status.equals("s"))) {
          throw new IllegalArgumentException("Invalid transaction status in portfolio file.");
        }


        try {
          int nos = Integer.parseInt(noOfStocks);
        } catch (NumberFormatException e) {
          throw new ParserConfigurationException("Invalid no. of shares in file.");
        }


        List<String> val_string = new ArrayList<>();
        val_string.add(dateTransaction);
        val_string.add(status);
        val_string.add(noOfStocks);

        if (!tv.checkTicker(ticker)) {
          throw new IllegalArgumentException("Invalid ticker in file.");
        }

        bd = dateTransaction.split("-");
        LocalDate bdDate = LocalDate.of(Integer.parseInt(bd[0]),
                Integer.parseInt(bd[1]), Integer.parseInt(bd[2]));
        s = new FlexiStocksImpl(Float.parseFloat(noOfStocks), 0, ticker, bdDate, status);

        if (status.equals("b")) {
          p.addStock(s);
        } else {
          if (!p.validateSell(bdDate, ticker, Float.parseFloat(noOfStocks))) {
            throw new IllegalArgumentException("Invalid transactions in portfolio "
                    + portfolioName + " file.");
          }
        }

        if (!h.containsKey(ticker)) {
          List<List<String>> s1 = new ArrayList<>();
          s1.add(val_string);
          h.put(ticker, s1);
        } else {
          h.get(ticker).add(val_string);
        }
      }
    }
    return h;
  }
}
