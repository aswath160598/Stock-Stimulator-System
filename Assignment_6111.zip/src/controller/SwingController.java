package controller;

import org.xml.sax.SAXException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import view.IView;

/**
 * This Interface represents the Swing Controller Module of our Portfolio Project.
 */
public interface SwingController {
  void setView(IView v);

  void buyStock(String portfolioName, String ticker, String buyDate, String nos, String commission);

  void sellStock(String portfolioName, String ticker, String sellDate,
                 String nos, String sellCommission);

  Map<String, Float> viewPortfolio(String portfolioName, String date);

  void savePortfolio(String portfolioName) throws FileNotFoundException,
          ParserConfigurationException, TransformerException;

  void loadPortfolio(String portfolioName) throws ParserConfigurationException,
          IOException, SAXException, TransformerException;

  void createDollarCostAveraging(String dcaName, String dcaPortfolioName, String dcaStartDate,
                                 String dcaEndDate, String dcaInvestmentAmount, String dcaInterval,
                                 String dcaPropMap, String dcaCommission)
          throws FileNotFoundException, ParserConfigurationException, TransformerException;

  void addFixedAmountInvestment(String fixedAmountName, String fixedAmountPortfolioName,
                                String fixedAmountDate, String fixedAmountInvestmentAmount,
                                String fixedAmountPropMap, String fixedAmountCommission);

  void calculatePortfolioValue(String portfolioValuePortfolioName, String portfolioValueDate);

  void calculateCB(String cbPortfolioName, String cbDate);

  void plotGraph(String plotGraphPortfolioName, String plotGraphStartDate, String plotGraphEndDate);
}
