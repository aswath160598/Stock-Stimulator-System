import controller.SwingController;
import controller.SwingControllerImpl;
import model.FlexiUser;
import model.FlexiUserImpl;
import utilities.GraphDraw;
import utilities.GraphDrawImpl;
import view.IView;
import view.JFrameView;

public class SwingMain {
  public static void main(String[] args) {

//    GraphDraw g = new GraphDrawImpl();
//    g.drawGUIGraph();

    FlexiUser user = new FlexiUserImpl();
    SwingController c = new SwingControllerImpl(user);
    IView view = new JFrameView("Portfolio Management System");
    c.setView(view);
  }
}
