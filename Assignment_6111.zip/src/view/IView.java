package view;

import controller.Features;
import utilities.GUIBarChart;

public interface IView {
  void addFeatures(Features features);

  void viewFixedAmountMenu();

  void viewPortfolioValueMenu();

  void viewPlotGraphMenu();

  void viewBuyMenu();

  void mainMenu();

  void viewSellMenu();

  void showWarningMessage(String message);

  void showInformationMessage(String message);

  void clearBuyPanelTextFields();

  void clearSellPanelTextFields();

  void viewPortfolioMenu();

  void viewSaveMenu();

  void viewLoadMenu();

  void viewDCAMenu();

  void showChart(GUIBarChart chart);
}
