package view;

import java.awt.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import controller.Features;
import model.TickerValidator;
import model.TickerValidatorImpl;
import utilities.GUIBarChart;
import utilities.StdDraw;

public class JFrameView extends JFrame implements IView {

  private JButton buyButton;
  private JButton sellButton;
  private JButton viewPortfolio;
  private JButton savePortfolio;
  private JButton loadPortfolio;
  private JButton viewCostBasis;
  private JButton viewPortfolioValue;
  private JButton plotGraph;
  private JButton dollarCostAveraging;
  private JButton investFixedAmount;
  private JButton buyBackButton;
  private JButton sellBackButton;
  private JButton viewPortfolioBackButton;
  private JButton savePortfolioBackButton;
  private JButton loadPortfolioBackButton;
  private JButton dcaBackButton;
  private JButton cbBackButton;
  private JButton addFixedAmountBackButton;
  private JButton portfolioValueBackButton;
  private JButton plotGraphBackButton;
  private JButton exitButton;
  private JPanel parentPanel;
  private JPanel menuPanel;
  private JPanel buyPanel;
  private JPanel sellPanel;
  private JPanel viewPanel;
  private JPanel savePanel;
  private JPanel loadPanel;
  private JPanel dcaPanel;
  private JPanel cbPanel;
  private JPanel graphPanel;
  private JPanel fixedAmountPanel;
  private JPanel portfolioValuePanel;
  private JTextField buyTicker;
  private JTextField buyPortfolio;
  private JLabel buyTickerLabel;
  private JLabel buyPortfolioNameLabel;
  private JTextField buyDate;
  private JLabel buyDateLabel;
  private JTextField buyNos;
  private JTextField buyCommission;
  private JLabel buyCommissionLabel;
  private JLabel buyCommissionValidationLabel;
  private JLabel buyNosLabel;
  private JLabel buyPortfolioValidationLabel;
  private JLabel buyTickerValidationLabel;
  private JLabel buyNosValidationLabel;
  private JLabel buyDateValidationLabel;
  private JButton buy;
  private JTextField sellTicker;
  private JTextField sellPortfolio;
  private JLabel sellTickerLabel;
  private JLabel sellPortfolioNameLabel;
  private JTextField sellDate;
  private JLabel sellDateLabel;
  private JTextField sellNos;
  private JTextField sellCommission;
  private JLabel sellCommissionLabel;
  private JLabel sellCommissionValidationLabel;
  private JLabel sellNosLabel;
  private JLabel sellTickerValidationLabel;
  private JLabel sellNosValidationLabel;
  private JLabel sellDateValidationLabel;
  private JLabel sellPortfolioValidationLabel;
  private JButton sell;

  private JLabel viewPortfolioNameLabel;
  private JTextField viewPortfolioName;
  private JLabel viewPortfolioNameValidationLabel;
  private JLabel viewPortfolioDateLabel;
  private JTextField viewPortfolioDate;
  private JLabel viewPortfolioDateValidationLabel;
  private JButton view;

  private JLabel savePortfolioNameLabel;
  private JTextField savePortfolioName;
  private JLabel savePortfolioNameValidationLabel;
  private JButton save;

  private JLabel loadPortfolioNameLabel;
  private JTextField loadPortfolioName;
  private JLabel loadPortfolioNameValidationLabel;
  private JButton load;


  private JLabel dcaNameLabel;
  private JTextField dcaName;
  private JLabel dcaNameValidationLabel;
  private JLabel dcaPortfolioNameLabel;
  private JTextField dcaPortfolioName;
  private JLabel dcaPortfolioNameValidationLabel;
  private JLabel dcaStartDateLabel;
  private JTextField dcaStartDate;
  private JLabel dcaStartDateValidationLabel;
  private JLabel dcaEndDateLabel;
  private JTextField dcaEndDate;
  private JLabel dcaEndDateValidationLabel;
  private JLabel dcaInvestmentAmountLabel;
  private JTextField dcaInvestmentAmount;
  private JLabel dcaInvestmentAmountValidationLabel;
  private JLabel dcaIntervalLabel;
  private JTextField dcaInterval;
  private JLabel dcaIntervalValidationLabel;
  private JLabel dcaPropMapLabel;
  private JTextField dcaPropMap;
  private JLabel dcaPropMapValidationLabel;
  private JLabel dcaCommissionLabel;
  private JTextField dcaCommission;
  private JLabel dcaCommissionValidationLabel;
  private JButton dcaAdd;


  private JLabel cbPortfolioNameLabel;
  private JTextField cbPortfolioName;
  private JLabel cbPortfolioNameValidationLabel;
  private JLabel cbDateLabel;
  private JTextField cbDate;
  private JLabel cbDateValidationLabel;
  private JButton calCB;


  private JLabel fixedAmountNameLabel;
  private JTextField fixedAmountName;
  private JLabel fixedAmountNameValidationLabel;
  private JLabel fixedAmountPortfolioNameLabel;
  private JTextField fixedAmountPortfolioName;
  private JLabel fixedAmountPortfolioNameValidationLabel;
  private JLabel fixedAmountDateLabel;
  private JTextField fixedAmountDate;
  private JLabel fixedAmountDateValidationLabel;
  private JLabel fixedAmountInvestmentAmountLabel;
  private JTextField fixedAmountInvestmentAmount;
  private JLabel fixedAmountInvestmentAmountValidationLabel;
  private JLabel fixedAmountPropMapLabel;
  private JTextField fixedAmountPropMap;
  private JLabel fixedAmountPropMapValidationLabel;
  private JLabel fixedAmountCommissionLabel;
  private JTextField fixedAmountCommission;
  private JLabel fixedAmountCommissionValidationLabel;
  private JButton fixedAmountAdd;

  private JLabel portfolioValuePortfolioNameLabel;
  private JTextField portfolioValuePortfolioName;
  private JLabel portfolioValuePortfolioNameValidationLabel;
  private JLabel portfolioValueDateLabel;
  private JTextField portfolioValueDate;
  private JLabel portfolioValueDateValidationLabel;
  private JButton calValue;

  private JLabel plotGraphPortfolioNameLabel;
  private JTextField plotGraphPortfolioName;
  private JLabel plotGraphPortfolioNameValidationLabel;
  private JLabel plotGraphStartDateLabel;
  private JTextField plotGraphStartDate;
  private JLabel plotGraphStartDateValidationLabel;
  private JLabel plotGraphEndDateLabel;
  private JTextField plotGraphEndDate;
  private JLabel plotGraphEndDateValidationLabel;
  private JButton plot;


  private CardLayout cardLayout;


  private Boolean buyPortfolioNameValid;
  private Boolean buyTickerValid;
  private Boolean buyDateValid;
  private Boolean buyNosValid;
  private Boolean buyCommissionValid;

  private Boolean sellPortfolioNameValid;
  private Boolean sellTickerValid;
  private Boolean sellDateValid;
  private Boolean sellNosValid;
  private Boolean sellCommissionValid;

  private Boolean viewPortfolioNameValid;
  private Boolean viewDateValid;

  private Boolean savePortfolioNameValid;

  private Boolean loadPortfolioNameValid;

  private Boolean dcaNameValid;
  private Boolean dcaPortfolioNameValid;
  private Boolean dcaStartDateValid;
  private Boolean dcaEndDateValid;
  private Boolean dcaInvestmentAmountValid;
  private Boolean dcaIntervalValid;
  private Boolean dcaPropMapValid;
  private Boolean dcaCommissionValid;

  private Boolean cbPortfolioNameValid;
  private Boolean cbDateValid;

  private Boolean fixedAmountNameValid;
  private Boolean fixedAmountPortfolioNameValid;
  private Boolean fixedAmountDateValid;
  private Boolean fixedAmountInvestmentAmountValid;
  private Boolean fixedAmountPropMapValid;
  private Boolean fixedAmountCommissionValid;

  private Boolean portfolioValuePortfolioNameValid;
  private Boolean portfolioValueDateValid;

  private Boolean plotGraphPortfolioNameValid;
  private Boolean plotGraphStartDateValid;
  private Boolean plotGraphEndDateValid;


  public JFrameView(String caption) {
    super(caption);


    buyPortfolioNameValid = false;
    buyTickerValid = false;
    buyDateValid = false;
    buyNosValid = false;
    buyCommissionValid = false;

    sellPortfolioNameValid = false;
    sellTickerValid = false;
    sellDateValid = false;
    sellNosValid = false;
    sellCommissionValid = false;

    viewPortfolioNameValid = false;
    viewDateValid = false;

    savePortfolioNameValid = false;

    loadPortfolioNameValid = false;

    dcaNameValid = false;
    dcaPortfolioNameValid = false;
    dcaStartDateValid = false;
    dcaEndDateValid = false;
    dcaInvestmentAmountValid = false;
    dcaIntervalValid = false;
    dcaPropMapValid = false;
    dcaCommissionValid = false;

    cbPortfolioNameValid = false;
    cbDateValid = false;

    fixedAmountNameValid = false;
    fixedAmountPortfolioNameValid = false;
    fixedAmountDateValid = false;
    fixedAmountInvestmentAmountValid = false;
    fixedAmountPropMapValid = false;
    fixedAmountCommissionValid = false;

    portfolioValuePortfolioNameValid = false;
    portfolioValueDateValid = false;

    plotGraphPortfolioNameValid = false;
    plotGraphStartDateValid = false;
    plotGraphEndDateValid = false;


    setSize(500, 300);
    setLocation(200, 200);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    cardLayout = new CardLayout();

    menuPanel = new JPanel();
    menuPanel.setLayout(new GridLayout(0, 3, 1, 1));
//    menuPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

    parentPanel = new JPanel();
    parentPanel.setLayout(cardLayout);

//    menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));

    buyButton = new JButton("Buy a Stock");
    buyButton.setActionCommand("Buy a Stock");
    menuPanel.add(buyButton);

    sellButton = new JButton("Sell a Stock");
    sellButton.setActionCommand("Sell a Stock");
    menuPanel.add(sellButton);

    viewPortfolio = new JButton("View a Portfolio");
    viewPortfolio.setActionCommand("View a Portfolio");
    menuPanel.add(viewPortfolio);

    savePortfolio = new JButton("Save a Portfolio");
    savePortfolio.setActionCommand("Save a Portfolio");
    menuPanel.add(savePortfolio);

    loadPortfolio = new JButton("Load a Portfolio");
    loadPortfolio.setActionCommand("Load a Portfolio");
    menuPanel.add(loadPortfolio);

    viewCostBasis = new JButton("View Cost Basis");
    viewCostBasis.setActionCommand("View Cost Basis");
    menuPanel.add(viewCostBasis);

    viewPortfolioValue = new JButton("View Portfolio Value");
    viewPortfolioValue.setActionCommand("View Portfolio Value");
    menuPanel.add(viewPortfolioValue);

    plotGraph = new JButton("Plot Graph");
    plotGraph.setActionCommand("Plot Graph");
    menuPanel.add(plotGraph);

    dollarCostAveraging = new JButton("Dollar Cost Averaging");
    dollarCostAveraging.setActionCommand("Dollar Cost Averaging");
    menuPanel.add(dollarCostAveraging);

    investFixedAmount = new JButton("Invest a Fixed Amount");
    investFixedAmount.setActionCommand("investFixedAmount");
    menuPanel.add(investFixedAmount);

    buyBackButton = new JButton("Back");
    buyBackButton.setActionCommand("Back");

    sellBackButton = new JButton("Back");
    sellBackButton.setActionCommand("Back");

    viewPortfolioBackButton = new JButton("Back");
    viewPortfolioBackButton.setActionCommand("Back");

    savePortfolioBackButton = new JButton("Back");
    savePortfolioBackButton.setActionCommand("Back");

    loadPortfolioBackButton = new JButton("Back");
    loadPortfolioBackButton.setActionCommand("Back");

    dcaBackButton = new JButton("Back");
    dcaBackButton.setActionCommand("Back");

    cbBackButton = new JButton("Back");
    cbBackButton.setActionCommand("Back");

    addFixedAmountBackButton = new JButton("Back");
    addFixedAmountBackButton.setActionCommand("Back");

    portfolioValueBackButton = new JButton("Back");
    portfolioValueBackButton.setActionCommand("Back");

    plotGraphBackButton = new JButton("Back");
    plotGraphBackButton.setActionCommand("Back");

    exitButton = new JButton("Exit");
    exitButton.setActionCommand("Exit");
    menuPanel.add(exitButton);

//    menuPanel.setVisible(true);
//    parentPanel.add(menuPanel);
    parentPanel.add(menuPanel, "menuPanel");

    buyTickerValidationLabel = new JLabel();
    buyTickerValidationLabel.setForeground(Color.red);
    buyNosValidationLabel = new JLabel();
    buyNosValidationLabel.setForeground(Color.red);
    buyDateValidationLabel = new JLabel();
    buyDateValidationLabel.setForeground(Color.red);
    buyPortfolioValidationLabel = new JLabel();
    buyPortfolioValidationLabel.setForeground(Color.red);
    buyCommissionValidationLabel = new JLabel();
    buyCommissionValidationLabel.setForeground(Color.red);

    buyPortfolioNameLabel = new JLabel("Enter Portfolio Name");
    buyTickerLabel = new JLabel("Enter ticker");
    buyDateLabel = new JLabel("Enter buy date (yyyy-mm-dd)");
    buyNosLabel = new JLabel("Enter no. of shares");
    buyCommissionLabel = new JLabel("Enter the commission fee for the transaction $");

    buyTicker = new JTextField(10);
    buyTicker.setToolTipText("Enter the stock ticker here (e.g. GOOG)");
    buyTicker.setInputVerifier(new tickerInputVerifier(buyTickerValidationLabel, "buy"));
    buyPortfolio = new JTextField(10);
    buyPortfolio.setToolTipText("Enter the Portfolio Name here (e.g. p1)");
    buyPortfolio.setInputVerifier(new portfolioNameVerifier(buyPortfolioValidationLabel, "buy"));
    buyDate = new JTextField(10);
    buyDate.setToolTipText("Enter the buy date here (e.g. 2022-11-28)");
    buyDate.setInputVerifier(new dateInputVerifier(buyDateValidationLabel, "buy"));
    buyNos = new JTextField(10);
    buyNos.setToolTipText("Enter the number of shares here (e.g. 10)");
    buyNos.setInputVerifier(new nosInputVerifier(buyNosValidationLabel, "buy"));
    buyCommission = new JTextField(10);
    buyCommission.setToolTipText("Enter the commission fee for the transaction here (e.g. 1)");
    buyCommission.setInputVerifier(new dcaInvestmentAmountInputVerifier(buyCommissionValidationLabel, "buyCommission"));

    buy = new JButton("Add to Portfolio");
    sell = new JButton("Sell Stock");


    buyPanel = new JPanel();
    buyPanel.setLayout(new GridLayout(0, 3, 1, 1));
    buyPanel.add(buyPortfolioNameLabel);
    buyPanel.add(buyPortfolio);
    buyPanel.add(buyPortfolioValidationLabel);
    buyPanel.add(buyTickerLabel);
    buyPanel.add(buyTicker);
    buyPanel.add(buyTickerValidationLabel);
    buyPanel.add(buyDateLabel);
    buyPanel.add(buyDate);
    buyPanel.add(buyDateValidationLabel);
    buyPanel.add(buyNosLabel);
    buyPanel.add(buyNos);
    buyPanel.add(buyNosValidationLabel);
    buyPanel.add(buyCommissionLabel);
    buyPanel.add(buyCommission);
    buyPanel.add(buyCommissionValidationLabel);
    buyPanel.add(buy);
    buyPanel.add(buyBackButton);


    sellTickerValidationLabel = new JLabel();
    sellTickerValidationLabel.setForeground(Color.red);
    sellNosValidationLabel = new JLabel();
    sellNosValidationLabel.setForeground(Color.red);
    sellDateValidationLabel = new JLabel();
    sellDateValidationLabel.setForeground(Color.red);
    sellPortfolioValidationLabel = new JLabel();
    sellPortfolioValidationLabel.setForeground(Color.red);
    sellCommissionValidationLabel = new JLabel();
    sellCommissionValidationLabel.setForeground(Color.red);


    sellPortfolioNameLabel = new JLabel("Enter Portfolio Name");
    sellTickerLabel = new JLabel("Enter ticker");
    sellDateLabel = new JLabel("Enter sell date (yyyy-mm-dd)");
    sellNosLabel = new JLabel("Enter no. of shares");
    sellCommissionLabel = new JLabel("Enter the commission fee for the transaction $");

    sellTicker = new JTextField(10);
    sellTicker.setToolTipText("Enter the stock ticker here (e.g. GOOG)");
    sellTicker.setInputVerifier(new tickerInputVerifier(sellTickerValidationLabel, "sell"));
    sellPortfolio = new JTextField(10);
    sellPortfolio.setToolTipText("Enter the Portfolio Name here (e.g. p1)");
    sellPortfolio.setInputVerifier(new portfolioNameVerifier(sellPortfolioValidationLabel, "sell"));
    sellDate = new JTextField(10);
    sellDate.setToolTipText("Enter the sell date here (e.g. 2022-11-28)");
    sellDate.setInputVerifier(new dateInputVerifier(sellDateValidationLabel, "sell"));
    sellNos = new JTextField(10);
    sellNos.setToolTipText("Enter the number of shares here (e.g. 10)");
    sellNos.setInputVerifier(new nosInputVerifier(sellNosValidationLabel, "sell"));
    sellCommission = new JTextField(10);
    sellCommission.setToolTipText("Enter the commission fee for the transaction here (e.g. 1)");
    sellCommission.setInputVerifier(new dcaInvestmentAmountInputVerifier(sellCommissionValidationLabel, "sellCommission"));


    sellPanel = new JPanel();
    sellPanel.setLayout(new GridLayout(0, 3, 1, 1));
    sellPanel.add(sellPortfolioNameLabel);
    sellPanel.add(sellPortfolio);
    sellPanel.add(sellPortfolioValidationLabel);
    sellPanel.add(sellTickerLabel);
    sellPanel.add(sellTicker);
    sellPanel.add(sellTickerValidationLabel);
    sellPanel.add(sellDateLabel);
    sellPanel.add(sellDate);
    sellPanel.add(sellDateValidationLabel);
    sellPanel.add(sellNosLabel);
    sellPanel.add(sellNos);
    sellPanel.add(sellNosValidationLabel);
    sellPanel.add(sellCommissionLabel);
    sellPanel.add(sellCommission);
    sellPanel.add(sellCommissionValidationLabel);
    sellPanel.add(sell);
    sellPanel.add(sellBackButton);


    viewPortfolioNameLabel = new JLabel("Enter Portfolio Name");
    viewPortfolioNameValidationLabel = new JLabel();
    viewPortfolioNameValidationLabel.setForeground(Color.red);
    viewPortfolioDateLabel = new JLabel("Enter date");
    viewPortfolioDateValidationLabel = new JLabel();
    viewPortfolioDateValidationLabel.setForeground(Color.red);

    viewPortfolioName = new JTextField(10);
    viewPortfolioName.setToolTipText("Enter the Portfolio Name here (e.g. p1)");
    viewPortfolioName.setInputVerifier(new portfolioNameVerifier(viewPortfolioNameValidationLabel, "view"));
    viewPortfolioDate = new JTextField(10);
    viewPortfolioDate.setToolTipText("Enter the date here (e.g. 2022-11-28)");
    viewPortfolioDate.setInputVerifier(new dateInputVerifier(viewPortfolioDateValidationLabel, "view"));

    view = new JButton("View Portfolio");

    viewPanel = new JPanel();
//    viewPanel.setLayout(new GridLayout(0, 3, 1, 1));
    viewPanel.add(viewPortfolioNameLabel);
    viewPanel.add(viewPortfolioName);
    viewPanel.add(viewPortfolioNameValidationLabel);
    viewPanel.add(viewPortfolioDateLabel);
    viewPanel.add(viewPortfolioDate);
    viewPanel.add(viewPortfolioDateValidationLabel);
    viewPanel.add(view);
    viewPanel.add(viewPortfolioBackButton);


    savePortfolioNameLabel = new JLabel("Enter Portfolio Name");
    savePortfolioNameValidationLabel = new JLabel();
    savePortfolioNameValidationLabel.setForeground(Color.red);

    savePortfolioName = new JTextField(10);
    savePortfolioName.setToolTipText("Enter the Portfolio Name here (e.g. p1)");
    savePortfolioName.setInputVerifier(new portfolioNameVerifier(savePortfolioNameValidationLabel, "save"));

    save = new JButton("Save");

    savePanel = new JPanel();
    savePanel.add(savePortfolioNameLabel);
    savePanel.add(savePortfolioName);
    savePanel.add(savePortfolioNameValidationLabel);
    savePanel.add(save);
    savePanel.add(savePortfolioBackButton);


    loadPortfolioNameLabel = new JLabel("Enter Portfolio Name");
    loadPortfolioNameValidationLabel = new JLabel();
    loadPortfolioNameValidationLabel.setForeground(Color.red);

    loadPortfolioName = new JTextField(10);
    loadPortfolioName.setToolTipText("Enter the Portfolio Name here (e.g. p1)");
    loadPortfolioName.setInputVerifier(new portfolioNameVerifier(loadPortfolioNameValidationLabel, "load"));

    load = new JButton("Load");

    loadPanel = new JPanel();
    loadPanel.add(loadPortfolioNameLabel);
    loadPanel.add(loadPortfolioName);
    loadPanel.add(loadPortfolioNameValidationLabel);
    loadPanel.add(load);
    loadPanel.add(loadPortfolioBackButton);


    dcaNameLabel = new JLabel("Enter dollar cost averaging strategy name");
    dcaName = new JTextField(10);
    dcaName.setToolTipText("Enter the Dollar Cost Averaging Strategy Name here (e.g. d1)");
//    dcaName.setMaximumSize(new Dimension(100, dcaName.getPreferredSize().height));
    dcaNameValidationLabel = new JLabel();
    dcaNameValidationLabel.setForeground(Color.red);
    dcaName.setInputVerifier(new portfolioNameVerifier(dcaNameValidationLabel, "dcaName"));
    dcaPortfolioNameLabel = new JLabel("Enter Portfolio Name");
    dcaPortfolioName = new JTextField(10);
    dcaPortfolioName.setToolTipText("Enter the Portfolio Name "
            + "to which Dollar Cost Averaging Strategy will be applied (e.g. p1)");
    dcaPortfolioNameValidationLabel = new JLabel();
    dcaPortfolioNameValidationLabel.setForeground(Color.red);
    dcaPortfolioName.setInputVerifier(new portfolioNameVerifier(dcaPortfolioNameValidationLabel, "dcaPortfolioName"));
    dcaStartDateLabel = new JLabel("Enter start date (yyyy-mm-dd)");
    dcaStartDate = new JTextField(10);
    dcaStartDate.setToolTipText("Enter the start date for "
            + "the Dollar Cost Averaging Strategy (e.g. 2020-03-04)");
    dcaStartDateValidationLabel = new JLabel();
    dcaStartDateValidationLabel.setForeground(Color.red);
    dcaStartDate.setInputVerifier(new futureDateInputVerifier(dcaStartDateValidationLabel, "dcaStartDate"));
    dcaEndDateLabel = new JLabel("Enter end date (yyyy-mm-dd) (optional)");
    dcaEndDate = new JTextField(10);
    dcaEndDate.setToolTipText("Enter the end date for the Dollar Cost Averaging Strategy. "
            + "Leave empty if no end date can be specified. (e.g. 2025-03-04)");
    dcaEndDateValidationLabel = new JLabel();
    dcaEndDateValidationLabel.setForeground(Color.red);
    dcaEndDate.setInputVerifier(new futureDateInputVerifier(dcaEndDateValidationLabel, "dcaEndDate"));
    dcaInvestmentAmountLabel = new JLabel("Enter amount $");
    dcaInvestmentAmount = new JTextField(10);
    dcaInvestmentAmount.setToolTipText("Enter the Investment amount "
            + "for the Dollar Cost Averaging Strategy (e.g. 1000)");
    dcaInvestmentAmountValidationLabel = new JLabel();
    dcaInvestmentAmountValidationLabel.setForeground(Color.red);
    dcaInvestmentAmount.setInputVerifier(new dcaInvestmentAmountInputVerifier(dcaInvestmentAmountValidationLabel, "dcaInvestmentAmount"));
    dcaIntervalLabel = new JLabel("Enter the interval (days)");
    dcaInterval = new JTextField(10);
    dcaInterval.setToolTipText("Enter the Interval (in no. of days) "
            + "for the Dollar Cost Averaging Strategy (e.g. 30)");
    dcaIntervalValidationLabel = new JLabel();
    dcaIntervalValidationLabel.setForeground(Color.red);
    dcaInterval.setInputVerifier(new dcaIntervalInputVerifier(dcaIntervalValidationLabel, "dcaInterval"));
    dcaPropMapLabel = new JLabel("Enter tickers and weightage (e.g. GOOG:10, AMZN:20)");
    dcaPropMap = new JTextField(30);
    dcaPropMap.setToolTipText("Enter the tickers and the weightage using colon "
            + "for stocks in the Dollar Cost Averaging Strategy "
            + "separated by comma (e.g. GOOG:10, AMZN:20)");
    dcaPropMapValidationLabel = new JLabel();
    dcaPropMapValidationLabel.setForeground(Color.red);
    dcaPropMap.setInputVerifier(new dcaPropMapInputVerifier(dcaPropMapValidationLabel, "dcaPropMap"));
    dcaCommissionLabel = new JLabel("Enter the commission for the Dollar Cost Averaging Strategy $");
    dcaCommission = new JTextField(10);
    dcaCommission.setToolTipText("Enter the commission for the Dollar Cost Averaging Strategy (e.g. 1)");
    dcaCommissionValidationLabel = new JLabel();
    dcaCommissionValidationLabel.setForeground(Color.red);
    dcaCommission.setInputVerifier(new dcaInvestmentAmountInputVerifier(dcaCommissionValidationLabel, "dcaCommission"));

    dcaAdd = new JButton("Add");

    dcaPanel = new JPanel();
    dcaPanel.setLayout(new GridLayout(0, 3, 1, 1));
    dcaPanel.add(dcaNameLabel);
    dcaPanel.add(dcaName);
    dcaPanel.add(dcaNameValidationLabel);
    dcaPanel.add(dcaPortfolioNameLabel);
    dcaPanel.add(dcaPortfolioName);
    dcaPanel.add(dcaPortfolioNameValidationLabel);
    dcaPanel.add(dcaStartDateLabel);
    dcaPanel.add(dcaStartDate);
    dcaPanel.add(dcaStartDateValidationLabel);
    dcaPanel.add(dcaEndDateLabel);
    dcaPanel.add(dcaEndDate);
    dcaPanel.add(dcaEndDateValidationLabel);
    dcaPanel.add(dcaInvestmentAmountLabel);
    dcaPanel.add(dcaInvestmentAmount);
    dcaPanel.add(dcaInvestmentAmountValidationLabel);
    dcaPanel.add(dcaIntervalLabel);
    dcaPanel.add(dcaInterval);
    dcaPanel.add(dcaIntervalValidationLabel);
    dcaPanel.add(dcaPropMapLabel);
    dcaPanel.add(dcaPropMap);
    dcaPanel.add(dcaPropMapValidationLabel);
    dcaPanel.add(dcaCommissionLabel);
    dcaPanel.add(dcaCommission);
    dcaPanel.add(dcaCommissionValidationLabel);
    dcaPanel.add(dcaAdd);
    dcaPanel.add(dcaBackButton);


    cbPortfolioNameLabel = new JLabel("Enter portfolio name");
    cbPortfolioName = new JTextField(10);
    cbPortfolioName.setToolTipText("Enter the Portfolio Name here (e.g. p1)");
    cbPortfolioNameValidationLabel = new JLabel();
    cbPortfolioNameValidationLabel.setForeground(Color.red);
    cbPortfolioName.setInputVerifier(new portfolioNameVerifier(cbPortfolioNameValidationLabel, "cbPortfolioName"));
    cbDateLabel = new JLabel("Enter the date");
    cbDate = new JTextField(10);
    cbDate.setToolTipText("Enter the date here (e.g. 2022-11-28)");
    cbDateValidationLabel = new JLabel();
    cbDateValidationLabel.setForeground(Color.red);
    cbDate.setInputVerifier(new futureDateInputVerifier(cbDateValidationLabel, "cbDate"));
    calCB = new JButton("Calculate Cost Basis");

    cbPanel = new JPanel();
    cbPanel.add(cbPortfolioNameLabel);
    cbPanel.add(cbPortfolioName);
    cbPanel.add(cbPortfolioNameValidationLabel);
    cbPanel.add(cbDateLabel);
    cbPanel.add(cbDate);
    cbPanel.add(cbDateValidationLabel);
    cbPanel.add(calCB);
    cbPanel.add(cbBackButton);


    fixedAmountNameLabel = new JLabel("Enter Fixed Investment Amount Strategy Name");
    fixedAmountName = new JTextField(10);
    fixedAmountName.setToolTipText("Enter the "
            + "Fixed Investment Amount Strategy Name here (e.g. f1)");
    fixedAmountNameValidationLabel = new JLabel();
    fixedAmountNameValidationLabel.setForeground(Color.red);
    fixedAmountName.setInputVerifier(new portfolioNameVerifier(fixedAmountNameValidationLabel, "fixedAmountName"));
    fixedAmountPortfolioNameLabel = new JLabel("Enter Portfolio Name");
    fixedAmountPortfolioName = new JTextField(10);
    fixedAmountPortfolioName.setToolTipText("Enter the Portfolio Name "
            + "to which Fixed Investment Amount Strategy will be applied (e.g. p1)");
    fixedAmountPortfolioNameValidationLabel = new JLabel();
    fixedAmountPortfolioNameValidationLabel.setForeground(Color.red);
    fixedAmountPortfolioName.setInputVerifier(new portfolioNameVerifier(fixedAmountPortfolioNameValidationLabel, "fixedAmountPortfolioName"));
    fixedAmountDateLabel = new JLabel("Enter investment date (yyyy-mm-dd)");
    fixedAmountDate = new JTextField(10);
    fixedAmountDate.setToolTipText("Enter the date for "
            + "the Fixed Investment Amount Strategy (e.g. 2020-03-04)");
    fixedAmountDateValidationLabel = new JLabel();
    fixedAmountDateValidationLabel.setForeground(Color.red);
    fixedAmountDate.setInputVerifier(new futureDateInputVerifier(fixedAmountDateValidationLabel, "fixedAmountDate"));
    fixedAmountInvestmentAmountLabel = new JLabel("Enter amount $");
    fixedAmountInvestmentAmount = new JTextField(10);
    fixedAmountInvestmentAmount.setToolTipText("Enter the Investment amount "
            + "for the Fixed Investment Amount Strategy (e.g. 1000)");
    fixedAmountInvestmentAmountValidationLabel = new JLabel();
    fixedAmountInvestmentAmountValidationLabel.setForeground(Color.red);
    fixedAmountInvestmentAmount.setInputVerifier(new dcaInvestmentAmountInputVerifier(fixedAmountInvestmentAmountValidationLabel, "fixedAmountInvestmentAmount"));
    fixedAmountPropMapLabel = new JLabel("Enter tickers "
            + "and weightage (e.g. GOOG:10, AMZN:20)");
    fixedAmountPropMap = new JTextField(30);
    fixedAmountPropMap.setToolTipText("Enter the tickers and the weightage using colon "
            + "for stocks in the Fixed Investment Amount Strategy "
            + "separated by comma (e.g. GOOG:10, AMZN:20)");
    fixedAmountPropMapValidationLabel = new JLabel();
    fixedAmountPropMapValidationLabel.setForeground(Color.red);
    fixedAmountPropMap.setInputVerifier(new dcaPropMapInputVerifier(fixedAmountPropMapValidationLabel, "fixedAmountPropMap"));
    fixedAmountCommissionLabel = new JLabel("Enter the commission for the Fixed Investment Amount Strategy $");
    fixedAmountCommission = new JTextField(10);
    fixedAmountCommission.setToolTipText("Enter the commission for the Fixed Investment Amount Strategy (e.g. 1)");
    fixedAmountCommissionValidationLabel = new JLabel();
    fixedAmountCommissionValidationLabel.setForeground(Color.red);
    fixedAmountCommission.setInputVerifier(new dcaInvestmentAmountInputVerifier(fixedAmountCommissionValidationLabel, "fixedAmountCommission"));

    fixedAmountAdd = new JButton("Add");

    fixedAmountPanel = new JPanel();
    fixedAmountPanel.setLayout(new GridLayout(0, 3, 1, 1));
    fixedAmountPanel.add(fixedAmountNameLabel);
    fixedAmountPanel.add(fixedAmountName);
    fixedAmountPanel.add(fixedAmountNameValidationLabel);
    fixedAmountPanel.add(fixedAmountPortfolioNameLabel);
    fixedAmountPanel.add(fixedAmountPortfolioName);
    fixedAmountPanel.add(fixedAmountPortfolioNameValidationLabel);
    fixedAmountPanel.add(fixedAmountDateLabel);
    fixedAmountPanel.add(fixedAmountDate);
    fixedAmountPanel.add(fixedAmountDateValidationLabel);
    fixedAmountPanel.add(fixedAmountInvestmentAmountLabel);
    fixedAmountPanel.add(fixedAmountInvestmentAmount);
    fixedAmountPanel.add(fixedAmountInvestmentAmountValidationLabel);
    fixedAmountPanel.add(fixedAmountPropMapLabel);
    fixedAmountPanel.add(fixedAmountPropMap);
    fixedAmountPanel.add(fixedAmountPropMapValidationLabel);
    fixedAmountPanel.add(fixedAmountCommissionLabel);
    fixedAmountPanel.add(fixedAmountCommission);
    fixedAmountPanel.add(fixedAmountCommissionValidationLabel);
    fixedAmountPanel.add(fixedAmountAdd);
    fixedAmountPanel.add(addFixedAmountBackButton);


    portfolioValuePortfolioNameLabel = new JLabel("Enter portfolio name");
    portfolioValuePortfolioName = new JTextField(10);
    portfolioValuePortfolioName.setToolTipText("Enter the Portfolio Name here (e.g. p1)");
    portfolioValuePortfolioNameValidationLabel = new JLabel();
    portfolioValuePortfolioNameValidationLabel.setForeground(Color.red);
    portfolioValuePortfolioName.setInputVerifier(new portfolioNameVerifier(portfolioValuePortfolioNameValidationLabel, "portfolioValuePortfolioName"));
    portfolioValueDateLabel = new JLabel("Enter the date");
    portfolioValueDate = new JTextField(10);
    portfolioValueDate.setToolTipText("Enter the date here (e.g. 2022-11-28)");
    portfolioValueDateValidationLabel = new JLabel();
    portfolioValueDateValidationLabel.setForeground(Color.red);
    portfolioValueDate.setInputVerifier(new dateInputVerifier(portfolioValueDateValidationLabel, "portfolioValueDate"));
    calValue = new JButton("Calculate Portfolio Value");

    portfolioValuePanel = new JPanel();
    portfolioValuePanel.add(portfolioValuePortfolioNameLabel);
    portfolioValuePanel.add(portfolioValuePortfolioName);
    portfolioValuePanel.add(portfolioValuePortfolioNameValidationLabel);
    portfolioValuePanel.add(portfolioValueDateLabel);
    portfolioValuePanel.add(portfolioValueDate);
    portfolioValuePanel.add(portfolioValueDateValidationLabel);
    portfolioValuePanel.add(calValue);
    portfolioValuePanel.add(portfolioValueBackButton);


    plotGraphPortfolioNameLabel = new JLabel("Enter portfolio name");
    plotGraphPortfolioName = new JTextField(10);
    plotGraphPortfolioName.setToolTipText("Enter the Portfolio Name here (e.g. p1)");
    plotGraphPortfolioNameValidationLabel = new JLabel();
    plotGraphPortfolioNameValidationLabel.setForeground(Color.red);
    plotGraphPortfolioName.setInputVerifier(new portfolioNameVerifier(plotGraphPortfolioNameValidationLabel, "plotGraphPortfolioName"));
    plotGraphStartDateLabel = new JLabel("Enter start the date");
    plotGraphStartDate = new JTextField(10);
    plotGraphStartDate.setToolTipText("Enter the start date here (e.g. 2022-11-28)");
    plotGraphStartDateValidationLabel = new JLabel();
    plotGraphStartDateValidationLabel.setForeground(Color.red);
    plotGraphStartDate.setInputVerifier(new dateInputVerifier(plotGraphStartDateValidationLabel, "plotGraphStartDate"));
    plotGraphEndDateLabel = new JLabel("Enter the end date");
    plotGraphEndDate = new JTextField(10);
    plotGraphEndDate.setToolTipText("Enter the end date here (e.g. 2022-12-28)");
    plotGraphEndDateValidationLabel = new JLabel();
    plotGraphEndDateValidationLabel.setForeground(Color.red);
    plotGraphEndDate.setInputVerifier(new dateInputVerifier(plotGraphEndDateValidationLabel, "plotGraphEndDate"));
    plot = new JButton("Plot Graph");

    graphPanel = new JPanel();
    graphPanel.add(plotGraphPortfolioNameLabel);
    graphPanel.add(plotGraphPortfolioName);
    graphPanel.add(plotGraphPortfolioNameValidationLabel);
    graphPanel.add(plotGraphStartDateLabel);
    graphPanel.add(plotGraphStartDate);
    graphPanel.add(plotGraphStartDateValidationLabel);
    graphPanel.add(plotGraphEndDateLabel);
    graphPanel.add(plotGraphEndDate);
    graphPanel.add(plotGraphEndDateValidationLabel);
    graphPanel.add(plot);
    graphPanel.add(plotGraphBackButton);


    parentPanel.add(buyPanel, "buyPanel");
    parentPanel.add(sellPanel, "sellPanel");
    parentPanel.add(viewPanel, "viewPanel");
    parentPanel.add(savePanel, "savePanel");
    parentPanel.add(loadPanel, "loadPanel");
    parentPanel.add(dcaPanel, "dcaPanel");
    parentPanel.add(cbPanel, "cbPanel");
    parentPanel.add(fixedAmountPanel, "fixedAmountPanel");
    parentPanel.add(portfolioValuePanel, "portfolioValuePanel");
    parentPanel.add(graphPanel, "graphPanel");


//    parentPanel.setVisible(true); // is this needed???

    this.setContentPane(parentPanel);
    cardLayout.show(parentPanel, "menuPanel");
//    cardLayout.show(parentPanel,"buyPanel");


    pack();
    setVisible(true);
  }

  @Override
  public void addFeatures(Features features) {
    buyBackButton.addActionListener(evt -> mainMenu());
    sellBackButton.addActionListener(evt -> mainMenu());
    viewPortfolioBackButton.addActionListener(evt -> mainMenu());
    savePortfolioBackButton.addActionListener(evt -> mainMenu());
    loadPortfolioBackButton.addActionListener(evt -> mainMenu());
    dcaBackButton.addActionListener(evt -> mainMenu());
    cbBackButton.addActionListener(evt -> mainMenu());
    addFixedAmountBackButton.addActionListener(evt -> mainMenu());
    portfolioValueBackButton.addActionListener(evt -> mainMenu());
    plotGraphBackButton.addActionListener(evt -> mainMenu());
    buyButton.addActionListener(evt -> viewBuyMenu());
    sellButton.addActionListener(evt -> viewSellMenu());
    viewPortfolio.addActionListener(evt -> viewPortfolioMenu());
    savePortfolio.addActionListener(evt -> viewSaveMenu());
    loadPortfolio.addActionListener(evt -> viewLoadMenu());
    viewCostBasis.addActionListener(evt -> viewCostBasisMenu());
    dollarCostAveraging.addActionListener(evt -> viewDCAMenu());
    investFixedAmount.addActionListener(evt -> viewFixedAmountMenu());
    viewPortfolioValue.addActionListener(evt -> viewPortfolioValueMenu());
    plotGraph.addActionListener(evt -> viewPlotGraphMenu());
    exitButton.addActionListener(evt -> features.exitProgram());
    buy.addActionListener(evt -> {
      if (buyPortfolioNameValid
              && buyTickerValid
              && buyDateValid
              && buyNosValid
              && buyCommissionValid) {
        features.buyClicked(buyPortfolio.getText(), buyTicker.getText(),
                buyDate.getText(), buyNos.getText(), buyCommission.getText());
      }
    });
    sell.addActionListener(evt -> {
      if (sellPortfolioNameValid && sellTickerValid && sellDateValid
              && sellNosValid && sellCommissionValid) {
        features.sellClicked(sellPortfolio.getText(), sellTicker.getText(),
                sellDate.getText(), sellNos.getText(), sellCommission.getText());
      }
    });
    view.addActionListener(evt -> {
      if (viewPortfolioNameValid && viewDateValid) {
        features.viewPortfolio(viewPortfolioName.getText(), viewPortfolioDate.getText());
      }
    });
    save.addActionListener(evt -> {
      if (savePortfolioNameValid) {
        features.savePortfolio(savePortfolioName.getText());
      }
    });
    load.addActionListener(evt -> {
      if (loadPortfolioNameValid) {
        features.loadPortfolio(loadPortfolioName.getText());
      }
    });
    dcaAdd.addActionListener(evt -> {
      if (dcaNameValid && dcaPortfolioNameValid && dcaStartDateValid && dcaEndDateValid
              && dcaInvestmentAmountValid && dcaIntervalValid && dcaPropMapValid
              && dcaCommissionValid) {
        try {
          features.addDCA(dcaName.getText(),
                  dcaPortfolioName.getText(),
                  dcaStartDate.getText(),
                  dcaEndDate.getText(),
                  dcaInvestmentAmount.getText(),
                  dcaInterval.getText(),
                  dcaPropMap.getText(),
                  dcaCommission.getText());
        } catch (FileNotFoundException e) {
          throw new RuntimeException(e);
        } catch (ParserConfigurationException e) {
          throw new RuntimeException(e);
        } catch (TransformerException e) {
          throw new RuntimeException(e);
        }
      }
    });
    calCB.addActionListener(evt -> {
      if (cbPortfolioNameValid && cbDateValid) {
        features.calculateCB(cbPortfolioName.getText(), cbDate.getText());
      }
    });
    fixedAmountAdd.addActionListener(evt -> {
      if (fixedAmountNameValid
              && fixedAmountPortfolioNameValid
              && fixedAmountDateValid
              && fixedAmountInvestmentAmountValid
              && fixedAmountPropMapValid
              && fixedAmountCommissionValid) {
        features.addFixedAmountInvestment(fixedAmountName.getText(),
                fixedAmountPortfolioName.getText(),
                fixedAmountDate.getText(),
                fixedAmountInvestmentAmount.getText(),
                fixedAmountPropMap.getText(),
                fixedAmountCommission.getText());
      }
    });
    calValue.addActionListener(evt -> {
      if (portfolioValuePortfolioNameValid && portfolioValueDateValid) {
        features.calculatePortfolioValue(portfolioValuePortfolioName.getText(),
                portfolioValueDate.getText());
      }
    });
    plot.addActionListener(evt -> {
      if (plotGraphPortfolioNameValid && plotGraphStartDateValid && plotGraphEndDateValid) {
        features.plotGraph(plotGraphPortfolioName.getText(),
                plotGraphStartDate.getText(), plotGraphEndDate.getText());
      }
    });
  }

  @Override
  public void viewBuyMenu() {
    cardLayout.show(parentPanel, "buyPanel");
  }

  @Override
  public void mainMenu() {
    cardLayout.show(parentPanel, "menuPanel");
  }

  @Override
  public void viewSellMenu() {
    cardLayout.show(parentPanel, "sellPanel");
  }

  private void viewCostBasisMenu() {
    cardLayout.show(parentPanel, "cbPanel");
  }

  @Override
  public void viewFixedAmountMenu() {
    cardLayout.show(parentPanel, "fixedAmountPanel");
  }

  @Override
  public void viewPortfolioValueMenu() {
    cardLayout.show(parentPanel, "portfolioValuePanel");
  }

  @Override
  public void viewPlotGraphMenu() {
    cardLayout.show(parentPanel, "graphPanel");
  }

  @Override
  public void showWarningMessage(String message) {
    JOptionPane.showMessageDialog(null,
            message,
            "",
            JOptionPane.WARNING_MESSAGE);
  }

  @Override
  public void showInformationMessage(String message) {
    JOptionPane.showMessageDialog(null,
            message,
            "",
            JOptionPane.INFORMATION_MESSAGE);
  }

  @Override
  public void clearBuyPanelTextFields() {
    buyPortfolio.setText("");
    buyTicker.setText("");
    buyDate.setText("");
    buyNos.setText("");
    buyCommission.setText("");
  }

  @Override
  public void clearSellPanelTextFields() {
    sellPortfolio.setText("");
    sellTicker.setText("");
    sellDate.setText("");
    sellNos.setText("");
    sellCommission.setText("");
  }

  @Override
  public void viewPortfolioMenu() {
    cardLayout.show(parentPanel, "viewPanel");
  }

  @Override
  public void viewSaveMenu() {
    cardLayout.show(parentPanel, "savePanel");
  }

  @Override
  public void viewLoadMenu() {
    cardLayout.show(parentPanel, "loadPanel");
  }

  @Override
  public void viewDCAMenu() {
    cardLayout.show(parentPanel, "dcaPanel");
  }

  @Override
  public void showChart(GUIBarChart chart) {
    chart.draw();
    StdDraw.show();
  }


  private class tickerInputVerifier extends InputVerifier {
    JLabel tickerValidationLabel;
    Boolean tickerValid;
    TickerValidator tv;
    String caller;

    {
      try {
        tv = new TickerValidatorImpl("stock_master_file.csv");
        tv.readFile();
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    }

    public tickerInputVerifier(JLabel tickerValidationLabel, String caller) {
      this.tickerValidationLabel = tickerValidationLabel;
      this.caller = caller;
    }

    public boolean verify(JComponent input) {
      JTextField textField = (JTextField) input;
      tickerValid = tv.checkTicker(textField.getText());
      if (textField.getText().equals("")) {
        tickerValid = false;
      }
      if (!tickerValid) {
        tickerValidationLabel.setText("Ticker is not valid!!!");
      } else {
        tickerValidationLabel.setText("");
      }
      switch (caller) {
        case "buy":
          buyTickerValid = tickerValid;
          break;
        case "sell":
          sellTickerValid = tickerValid;
          break;
        default:
          break;
      }
      return tickerValid;
    }
  }

  private class nosInputVerifier extends InputVerifier {
    JLabel nosValidationLabel;
    Boolean nosValid;
    String caller;

    public nosInputVerifier(JLabel nosValidationLabel, String caller) {
      this.nosValidationLabel = nosValidationLabel;
      this.caller = caller;
    }

    public boolean verify(JComponent input) {
      JTextField textField = (JTextField) input;
      String nos = textField.getText();
      nosValid = true;
      try {
        if (Float.parseFloat(nos) <= 0) {
          nosValid = false;
        } else if (Float.parseFloat(nos) - Math.floor(Float.parseFloat(nos)) > 0) {
          nosValid = false;
        }
      } catch (NumberFormatException e) {
        nosValid = false;
      }
      if (!nosValid) {
        nosValidationLabel.setText("Number of shares is not valid!!!");
      } else {
        nosValidationLabel.setText("");
      }
      switch (caller) {
        case "buy":
          buyNosValid = nosValid;
          break;
        case "sell":
          sellNosValid = nosValid;
          break;
        default:
          break;
      }
      return nosValid;
    }
  }

  private class dcaIntervalInputVerifier extends InputVerifier {
    JLabel intervalValidationLabel;
    Boolean intervalValid;
    String caller;

    public dcaIntervalInputVerifier(JLabel intervalValidationLabel, String caller) {
      this.intervalValidationLabel = intervalValidationLabel;
      this.caller = caller;
    }

    public boolean verify(JComponent input) {
      JTextField textField = (JTextField) input;
      String nos = textField.getText();
      intervalValid = true;
      try {
        if (Float.parseFloat(nos) <= 0) {
          intervalValid = false;
        } else if (Float.parseFloat(nos) - Math.floor(Float.parseFloat(nos)) > 0) {
          intervalValid = false;
        }
      } catch (NumberFormatException e) {
        intervalValid = false;
      }
      if (!intervalValid) {
        intervalValidationLabel.setText("Interval is not valid!!!");
      } else {
        intervalValidationLabel.setText("");
      }
      switch (caller) {
        case "dcaInterval":
          dcaIntervalValid = intervalValid;
          break;
        default:
          break;
      }
      return intervalValid;
    }
  }

  private class dcaInvestmentAmountInputVerifier extends InputVerifier {
    JLabel amountValidationLabel;
    Boolean amountValid;
    String caller;

    public dcaInvestmentAmountInputVerifier(JLabel amountValidationLabel, String caller) {
      this.amountValidationLabel = amountValidationLabel;
      this.caller = caller;
    }

    public boolean verify(JComponent input) {
      JTextField textField = (JTextField) input;
      String amount = textField.getText();
      amountValid = true;
      try {
        if (Float.parseFloat(amount) <= 0) {
          amountValid = false;
        }
      } catch (NumberFormatException e) {
        amountValid = false;
      }
      if (!amountValid) {
        amountValidationLabel.setText("Amount is not valid!!!");
      } else {
        amountValidationLabel.setText("");
      }
      switch (caller) {
        case "dcaInvestmentAmount":
          dcaInvestmentAmountValid = amountValid;
          break;
        case "fixedAmountInvestmentAmount":
          fixedAmountInvestmentAmountValid = amountValid;
          break;
        case "buyCommission":
          buyCommissionValid = amountValid;
          break;
        case "sellCommission":
          sellCommissionValid = amountValid;
          break;
        case "dcaCommission":
          dcaCommissionValid = amountValid;
          break;
        case "fixedAmountCommission":
          fixedAmountCommissionValid = amountValid;
          break;
        default:
          break;
      }
      return amountValid;
    }
  }

  private class dateInputVerifier extends InputVerifier {
    JLabel dateValidationLabel;
    Boolean dateValid;
    String caller;

    public dateInputVerifier(JLabel dateValidationLabel, String caller) {
      this.dateValidationLabel = dateValidationLabel;
      this.caller = caller;
    }

    public boolean verify(JComponent input) {
      JTextField textField = (JTextField) input;
      try {
        // ResolverStyle.STRICT for 30, 31 days checking, and also leap year.
        LocalDate d = LocalDate.parse(textField.getText(),
                DateTimeFormatter.ofPattern("uuuu-MM-dd")
                        .withResolverStyle(ResolverStyle.STRICT));

        dateValid = !d.isAfter(LocalDate.now());

      } catch (DateTimeParseException e) {
        dateValid = false;
      }

      if (textField.getText().equals("")) {
        dateValid = false;
      }

      if (!dateValid) {
        dateValidationLabel.setText("Date is not valid!!!");
      } else {
        dateValidationLabel.setText("");
      }
      switch (caller) {
        case "buy":
          buyDateValid = dateValid;
          break;
        case "sell":
          sellDateValid = dateValid;
          break;
        case "view":
          viewDateValid = dateValid;
          break;
        case "portfolioValueDate":
          portfolioValueDateValid = dateValid;
          break;
        case "plotGraphStartDate":
          plotGraphStartDateValid = dateValid;
          break;
        case "plotGraphEndDate":
          plotGraphEndDateValid = dateValid;
          break;
        default:
          break;
      }
      return dateValid;
    }
  }

  private class futureDateInputVerifier extends InputVerifier {
    JLabel dateValidationLabel;
    Boolean dateValid;
    String caller;

    public futureDateInputVerifier(JLabel dateValidationLabel, String caller) {
      this.dateValidationLabel = dateValidationLabel;
      this.caller = caller;
      this.dateValid = true;
    }

    public boolean verify(JComponent input) {
      JTextField textField = (JTextField) input;
      dateValid = true;
      try {
        // ResolverStyle.STRICT for 30, 31 days checking, and also leap year.
        LocalDate d = LocalDate.parse(textField.getText(),
                DateTimeFormatter.ofPattern("uuuu-MM-dd")
                        .withResolverStyle(ResolverStyle.STRICT));

      } catch (DateTimeParseException e) {
        dateValid = false;
      }

      if (textField.getText().equals("")) {
        dateValid = false;
        if (caller.equals("dcaEndDate")) {
          dateValid = true;
        }
      }

      if (!dateValid) {
        dateValidationLabel.setText("Date is not valid!!!");
      } else {
        dateValidationLabel.setText("");
      }
      switch (caller) {
        case "dcaStartDate":
          dcaStartDateValid = dateValid;
          break;
        case "dcaEndDate":
          dcaEndDateValid = dateValid;
          break;
        case "cbDate":
          cbDateValid = dateValid;
          break;
        case "fixedAmountDate":
          fixedAmountDateValid = dateValid;
          break;
        default:
          break;
      }
      return dateValid;
    }
  }

  private class portfolioNameVerifier extends InputVerifier {
    JLabel portfolioValidationLabel;
    Boolean portfolioNameValid;
    String caller;

    public portfolioNameVerifier(JLabel portfolioValidationLabel, String caller) {
      this.portfolioValidationLabel = portfolioValidationLabel;
      this.caller = caller;
    }

    public boolean verify(JComponent input) {
      portfolioNameValid = true;
      JTextField textField = (JTextField) input;
      if (textField.getText().trim().equals("")) {
        portfolioNameValid = false;
      }
      if (!portfolioNameValid) {
        portfolioValidationLabel.setText("Name is not valid!!!");
      } else {
        portfolioValidationLabel.setText("");
      }
      switch (caller) {
        case "buy":
          buyPortfolioNameValid = portfolioNameValid;
          break;
        case "sell":
          sellPortfolioNameValid = portfolioNameValid;
          break;
        case "view":
          viewPortfolioNameValid = portfolioNameValid;
          break;
        case "save":
          savePortfolioNameValid = portfolioNameValid;
          break;
        case "load":
          loadPortfolioNameValid = portfolioNameValid;
          break;
        case "dcaName":
          dcaNameValid = portfolioNameValid;
          break;
        case "dcaPortfolioName":
          dcaPortfolioNameValid = portfolioNameValid;
          break;
        case "cbPortfolioName":
          cbPortfolioNameValid = portfolioNameValid;
          break;
        case "fixedAmountName":
          fixedAmountNameValid = portfolioNameValid;
          break;
        case "fixedAmountPortfolioName":
          fixedAmountPortfolioNameValid = portfolioNameValid;
          break;
        case "portfolioValuePortfolioName":
          portfolioValuePortfolioNameValid = portfolioNameValid;
          break;
        case "plotGraphPortfolioName":
          plotGraphPortfolioNameValid = portfolioNameValid;
          break;
        default:
          break;
      }
      return portfolioNameValid;
    }
  }


  private class dcaPropMapInputVerifier extends InputVerifier {
    JLabel propMapValidationLabel;
    Boolean propMapValid;
    String caller;
    TickerValidator tv;

    {
      try {
        tv = new TickerValidatorImpl("stock_master_file.csv");
        tv.readFile();
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    }

    public dcaPropMapInputVerifier(JLabel propMapValidationLabel, String caller) {
      this.propMapValidationLabel = propMapValidationLabel;
      this.caller = caller;
    }

    public boolean verify(JComponent input) {
      propMapValid = true;
      JTextField textField = (JTextField) input;

      List<String> propMap = List.of(textField.getText().split(","));

      List<String> tickers = new ArrayList<>();
      List<String> weightsString = new ArrayList<>();

      for (String s : propMap) {
        try {
          tickers.add(s.split(":")[0].trim());
          weightsString.add(s.split(":")[1]);
        } catch (ArrayIndexOutOfBoundsException e) {
          propMapValid = false;
        }
      }

      for (String ticker : tickers) {
        if (!tv.checkTicker(ticker)) {
          propMapValid = false;
          break;
        }
      }

      float sum = 0F;

      for (String weight : weightsString) {
        try {
          if (Float.parseFloat(weight) <= 0) {
            propMapValid = false;
          } else {
            sum += Float.parseFloat(weight);
          }
        } catch (NumberFormatException e) {
          propMapValid = false;
        }
      }

      if (sum != 100) {
        propMapValid = false;
      }

      if (textField.getText().equals("")) {
        propMapValid = false;
      }
      if (!propMapValid) {
        propMapValidationLabel.setText("Invalid Input!!!");
      } else {
        propMapValidationLabel.setText("");
      }
      switch (caller) {
        case "dcaPropMap":
          dcaPropMapValid = propMapValid;
          break;
        case "fixedAmountPropMap":
          fixedAmountPropMapValid = propMapValid;
          break;
        default:
          break;
      }
      return propMapValid;
    }
  }
}