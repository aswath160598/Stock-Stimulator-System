import org.xml.sax.SAXException;

import java.io.IOException;
import java.text.ParseException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import controller.FlexiController;
import controller.FlexiControllerImpl;
import controller.SwingController;
import controller.SwingControllerImpl;
import model.FlexiUser;
import model.FlexiUserImpl;
import view.FlexiView;
import view.FlexiViewImpl;
import view.IView;
import view.JFrameView;

/**
 * This represents the main method of our project.
 */
public class Main {
  /**
   * This is the main driver function of the project.
   *
   * @param args The arguments passed
   * @throws ParseException               This exception throws when errors in Parsing is found.
   * @throws IOException                  This exception throws when errors in IO is found.
   * @throws ParserConfigurationException This exception throws when errors in Parse Conf is found.
   * @throws TransformerException         This exception throws when errors in Transforming is found.
   */
  public static void main(String[] args)
          throws ParseException, IOException, ParserConfigurationException, TransformerException,
          SAXException {
    if (args[0].equals("text")) {
      FlexiUser u = new FlexiUserImpl();
      FlexiView v = new FlexiViewImpl(System.out);
      FlexiController fc = new FlexiControllerImpl(u, v, System.in);
      fc.showPortfolioTypeSelection();
    } else if (args[0].equals("gui")) {
      FlexiUser user = new FlexiUserImpl();
      SwingController c = new SwingControllerImpl(user);
      IView view = new JFrameView("Portfolio Management System");
      c.setView(view);
    } else {
      System.out.println("Invalid arguments.");
    }
  }
}
