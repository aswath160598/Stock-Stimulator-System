import org.junit.Before;
import org.junit.Test;
import org.xml.sax.SAXException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import controller.FlexiController;
import controller.FlexiControllerImpl;
import model.FlexiUser;
import model.FlexiUserImpl;
import view.FlexiView;
import view.FlexiViewImpl;

public class FlexiControllerImplTest {

  private FlexiController fc;
  private InputStream in;
  private ByteArrayOutputStream bytes;
  private FlexiUser user;
  private FlexiView view;

  @Before
  public void setUp() {

    bytes = new ByteArrayOutputStream();
    PrintStream out = new PrintStream(bytes);
    view = new FlexiViewImpl(out);

    user = new FlexiUserImpl();
  }

  @Test
  public void buyStockTest1() throws FileNotFoundException {
    // creation of new portfolio

    in = new ByteArrayInputStream("GOOG 2020-01-01 10 y AMZN 2022-01-01 20 n".getBytes());
    fc = new FlexiControllerImpl(user, view, in);

    fc.buyStock("p1");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2021, 1, 2)));
  }

  @Test
  public void buyStockTest2() throws FileNotFoundException {
    // creation of new portfolio same stock on different dates

    in = new ByteArrayInputStream(("GOOG 2020-01-01 10 y GOOG 2020-01-02 10 y "
            + "AMZN 2022-01-01 20 y AMZN 2022-01-02 20 n").getBytes());
    fc = new FlexiControllerImpl(user, view, in);

    fc.buyStock("p1");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2021, 1, 2)));

    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 2, 2)));
  }

  @Test
  public void buyStockTest3() throws FileNotFoundException {
    // creation of new portfolio same stock on same dates

    in = new ByteArrayInputStream(("GOOG 2020-01-01 10 y GOOG 2020-01-01 10 y "
            + "AMZN 2022-01-01 20 y AMZN 2022-01-01 20 n").getBytes());
    fc = new FlexiControllerImpl(user, view, in);

    fc.buyStock("p1");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2021, 1, 2)));

    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 2, 2)));
  }

  @Test
  public void buyStockTest4() throws FileNotFoundException {
    // addition to existing portfolio

    List<List<String>> val_string1 = new ArrayList<>();
    List<String> val_string = new ArrayList<>();
    val_string.add("2020-09-01");
    val_string.add("b");
    val_string.add("5");
    Map<String, List<List<String>>> h = new HashMap<>();
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2020-08-01");
    val_string.add("b");
    val_string.add("12");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2020-08-05");
    val_string.add("s");
    val_string.add("3");
    val_string1.add(val_string);
    h.put("GOOG", val_string1);

    // creating portfolio p1 for the user
    user.addNewFlexiPortfolio(h, "p1");

//    System.out.println(user.getPortfolio("p1").getComposition(LocalDate.of(2022,1,1)));

    in = new ByteArrayInputStream("MSFT 2020-01-01 10 y AMZN 2022-01-01 20 n".getBytes());

    // user already has a portfolio called p1
    fc = new FlexiControllerImpl(user, view, in);

    fc.buyStock("p1");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2021, 1, 2)));

    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 1, 2)));
  }

  @Test
  public void sellStockTest1() throws FileNotFoundException {
    // creation of new portfolio with 2 stocks and sell 2 of each stock

    in = new ByteArrayInputStream(("GOOG 2021-03-01 10 y AMZN 2021-01-01 20 n "
            + "GOOG 2021-01-02 2 y AMZN 2021-01-02 2 n").getBytes());

    fc = new FlexiControllerImpl(user, view, in);

    fc.buyStock("p1");
    System.out.println("\nportfolio before selling");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 1, 2)));
    System.out.println();

    fc.sellStock("p1");

    System.out.println("\nportfolio after selling");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 1, 2)));
  }

  @Test
  public void sellStockTest2() throws FileNotFoundException {
    // creation of new portfolio with 2 stocks and
    // sell 2 of each stock in two different transactions

    in = new ByteArrayInputStream(("GOOG 2020-01-01 10 y AMZN 2021-01-01 20 n "
            + "GOOG 2021-01-01 2 y GOOG 2021-01-01 2 y AMZN 2021-01-02 2 n").getBytes());
    fc = new FlexiControllerImpl(user, view, in);

    fc.buyStock("p1");
    System.out.println("\nportfolio before selling");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 1, 2)));
    System.out.println();

    fc.sellStock("p1");

    System.out.println("\nportfolio after selling");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 1, 2)));
  }

  @Test
  public void sellStockTest3() throws FileNotFoundException {
    // creation of new portfolio with 2 stocks and sell on buy day

    in = new ByteArrayInputStream(("GOOG 2020-01-01 10 y AMZN 2021-01-01 20 n "
            + "GOOG 2020-01-01 2 y AMZN 2021-01-01 2 n").getBytes());
    fc = new FlexiControllerImpl(user, view, in);

    fc.buyStock("p1");
    System.out.println("\nportfolio before selling");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 1, 2)));
    System.out.println();

    fc.sellStock("p1");

    System.out.println("\nportfolio after selling");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 1, 2)));
  }

  @Test
  public void sellStockTest4() throws FileNotFoundException {
    // creation of new portfolio with 2 stocks and sell 2 of each stock

    in = new ByteArrayInputStream(("GOOG 2021-03-01 10 y AMZN 2021-01-01 20 n "
            + "GOOG 2021-01-02 2 y AMZN 2021-01-02 12 y AMZN 2021-01-01 9 n").getBytes());
    fc = new FlexiControllerImpl(user, view, in);

    fc.buyStock("p1");
    System.out.println("\nportfolio before selling");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 1, 2)));
    System.out.println();

    fc.sellStock("p1");

    System.out.println("\nportfolio after selling");
    System.out.println(user.getPortfolio("p1")
            .getComposition(LocalDate.of(2022, 1, 2)));
  }

  @Test
  public void sellStockTest5() throws ParseException, IOException, ParserConfigurationException, TransformerException, SAXException {
    // creation of new portfolio with 2 stocks and sell 2 of each stock

    view = new FlexiViewImpl(System.out);

    in = new ByteArrayInputStream(("2 1 p1 goog 2020-01-01 5 y goog 2020-02-02 7 n "
            + "2 p1 goog 2020-02-05 8 y goog 2020-02-04 5 n 3 p1 9 9").getBytes());
    fc = new FlexiControllerImpl(user, view, in);

//    fc.buyStock("p1");
//    System.out.println("\nportfolio before selling");
//    System.out.println(user.getPortfolio("p1")
//            .getComposition(LocalDate.of(2022, 1, 2)));
//    System.out.println();

//    fc.sellStock("p1");

//    System.out.println("\nportfolio after selling");
//    System.out.println(user.getPortfolio("p1")
//            .getComposition(LocalDate.of(2022, 1, 2)));

    fc.showPortfolioTypeSelection();
  }

  @Test
  public void invalidDateTest1() throws ParseException, IOException, ParserConfigurationException, TransformerException, SAXException {
    // creation of new portfolio with 2 stocks and sell 2 of each stock

    view = new FlexiViewImpl(System.out);

//    in = new ByteArrayInputStream(("2 1 p1 goog 2020-01-01 5 y goog 2020-02-02 7 n "
//            + "2 p1 goog 2020-02-05 8 y goog 2020-02-04 5 n 3 p1 9 9").getBytes());

    in = new ByteArrayInputStream(("2 1 p1 goog 2020/01/01 5 y goog 2020-02-02 7 n "
            + "2 p1 goog 2020-02-05 8 y goog 2020-02-04 5 n 3 p1 9 9").getBytes());

    fc = new FlexiControllerImpl(user, view, in);

//    fc.buyStock("p1");
//    System.out.println("\nportfolio before selling");
//    System.out.println(user.getPortfolio("p1")
//            .getComposition(LocalDate.of(2022, 1, 2)));
//    System.out.println();

//    fc.sellStock("p1");

//    System.out.println("\nportfolio after selling");
//    System.out.println(user.getPortfolio("p1")
//            .getComposition(LocalDate.of(2022, 1, 2)));

    fc.showPortfolioTypeSelection();
  }

  @Test
  public void loadShowPortfolioTest1() throws ParseException, IOException, ParserConfigurationException, TransformerException, SAXException {

    view = new FlexiViewImpl(System.out);

    in = new ByteArrayInputStream(("2 5 p1 3 p1 9 9").getBytes());

    fc = new FlexiControllerImpl(user, view, in);


    fc.showPortfolioTypeSelection();

  }
}
