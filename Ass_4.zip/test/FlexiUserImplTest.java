import org.junit.Before;
import org.junit.Test;
import org.xml.sax.SAXException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import model.FlexiPortfolio;
import model.FlexiPortfolioImpl;
import model.FlexiUser;
import model.FlexiUserImpl;
import model.GraphDrawImpl;

import static org.junit.Assert.assertEquals;

public class FlexiUserImplTest {

  private FlexiUser user;
  private FlexiUser u1;
  private FlexiPortfolio p;
  private FlexiPortfolio p1;
  private StringBuilder log;
  private ByteArrayInputStream in;

  @Before
  public void setUp() {
    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    PrintStream out = new PrintStream(bytes);
  }

  @Test
  public void test5() throws ParseException {
    List<List<String>> val_string1 = new ArrayList<>();
    List<String> val_string = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("b");
    val_string.add("1");
    Map<String, List<List<String>>> h = new HashMap<>();
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("s");
    val_string.add("1");
    val_string1.add(val_string);
    h.put("AMZN", val_string1);
    val_string = new ArrayList<>();
    val_string1 = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    h.put("GOOG", val_string1);
    p = new FlexiPortfolioImpl(h);
    user = new FlexiUserImpl();
    user.addNewFlexiPortfolio(h, "p1");
//    u.addNewFlexiPortfolio(h2, "p2");
    float x = 0;
    x = user.getFlexiPortfolioValue("p1", "2022-11-09");
    assertEquals(348.34002685546875, x, 0);
  }

  @Test
  public void costBasisTest1() {

    user = new FlexiUserImpl();

    List<List<String>> val_string1 = new ArrayList<>();
    List<String> val_string = new ArrayList<>();
    val_string.add("2022-11-09");
    val_string.add("b");
    val_string.add("3");
    Map<String, List<List<String>>> h = new HashMap<>();
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2022-11-09");
    val_string.add("s");
    val_string.add("2");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2022-11-09");
    val_string.add("s");
    val_string.add("1");
    val_string1.add(val_string);
    h.put("GOOG", val_string1);

    // creating portfolio p1 for the user
    user.addNewFlexiPortfolio(h, "p1");

    try {
      System.out.println(user.getPortfolio("p1")
              .getComposition(LocalDate.of(2022,11,10)));
      System.out.println(user.calculateCostBasis("p1", "2022-11-10"));
    } catch (ParseException e) {
      throw new RuntimeException(e);
    }
  }

  @Test
  public void test6() throws ParseException, IOException, ParserConfigurationException, TransformerException, SAXException {
    List<List<String>> val_string1 = new ArrayList<>();
    List<String> val_string = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("b");
    val_string.add("1");
    Map<String, List<List<String>>> h = new HashMap<>();
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("s");
    val_string.add("1");
    val_string1.add(val_string);
    h.put("AMZN", val_string1);
    val_string = new ArrayList<>();
    val_string1 = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2022-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    h.put("GOOG", val_string1);
    p = new FlexiPortfolioImpl(h);
    user = new FlexiUserImpl();
    user.addNewFlexiPortfolio(h, "p1");
    float x = 0;
    user.saveFlexiPortfolio("p1");
    System.out.println(user.getPortfolio("p1"));
    user.loadFlexiPortfolio("p1");
    System.out.println(user.getPortfolio("p1"));
  }

  @Test
  public void test7() throws ParseException, IOException, ParserConfigurationException, TransformerException, SAXException {
    user = new FlexiUserImpl();
    System.out.println(user.getPortfolio("p1"));
    user.loadFlexiPortfolio("p1");
    user.getPortfolio("p1");
    System.out.println(user.getPortfolio("p1"));
  }

  @Test
  public void test8() throws ParseException {
    List<List<String>> val_string1 = new ArrayList<>();
    List<String> val_string = new ArrayList<>();
    val_string.add("2021-11-08");
    val_string.add("b");
    val_string.add("1");
    Map<String, List<List<String>>> h = new HashMap<>();
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2021-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2021-11-08");
    val_string.add("s");
    val_string.add("1");
    val_string1.add(val_string);
    h.put("GOOG", val_string1);
    val_string = new ArrayList<>();
    val_string1 = new ArrayList<>();
    val_string.add("2021-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2021-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2021-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    h.put("AAPL", val_string1);
    p = new FlexiPortfolioImpl(h);
    user = new FlexiUserImpl();
    user.addNewFlexiPortfolio(h, "p1");
//    System.out.println(user.getFlexiPortfolioValue("p1", "2022-11-09"));
//    System.out.println(user.getPortfolio("p1"));
    user.drawGraph("p1","2018-01-15", "2022-10-15");
  }

  @Test
  public void testForMonths() throws ParseException {
    List<List<String>> val_string1 = new ArrayList<>();
    List<String> val_string = new ArrayList<>();
    val_string.add("2016-11-08");
    val_string.add("b");
    val_string.add("1");
    Map<String, List<List<String>>> h = new HashMap<>();
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2016-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2017-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    h.put("GOOG", val_string1);
    val_string = new ArrayList<>();
    val_string1 = new ArrayList<>();
    val_string.add("2017-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2016-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    val_string = new ArrayList<>();
    val_string.add("2017-11-08");
    val_string.add("b");
    val_string.add("1");
    val_string1.add(val_string);
    h.put("AAPL", val_string1);
    p = new FlexiPortfolioImpl(h);
    user = new FlexiUserImpl();
    user.addNewFlexiPortfolio(h, "p1");
    user.drawGraph("p1","2016-10-15", "2017-12-15");
  }
}
