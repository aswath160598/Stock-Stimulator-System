package controller;

import org.xml.sax.SAXException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

public interface FlexiController extends Controller {
  void showPortfolioTypeSelection() throws ParseException, IOException, ParserConfigurationException, TransformerException, SAXException;

  void flexibleOperations() throws ParseException, IOException, ParserConfigurationException, TransformerException, SAXException;

  void buyStock(String portfolioName) throws FileNotFoundException;

  void sellStock(String portfolioName);
}
