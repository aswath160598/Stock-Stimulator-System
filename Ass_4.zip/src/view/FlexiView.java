package view;

public interface FlexiView extends View {
  void selectPortfolioType();

  void showFlexibleMenu();

  void enterTicker();

  void enterBuyDate();

  void enterNOS();

  void enterSellTicker();

  void enterSellDate();

  void enterSellQuantity();

  void stockSold();

  void stockNotSold();

  void sellAnotherStock();

  void displayCostBasis(float cb, String portfolioName);

  void showPortfolio(String ticker, int noOfShares);

  void showError(String err);

  void futureDate();
}
