package model;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.Map;

public interface FlexiPortfolio extends Portfolio {
  Map<String, Float> getComposition(LocalDate date);

  Boolean validateSell(LocalDate sellDate, String ticker, Float sellQuantity);

  void addStock(FlexiStocks s);

  float calculatePortfolioCostBasis(float commission, String date) throws ParseException;

  int size();

  FlexiStocks getAt(int x);
}
