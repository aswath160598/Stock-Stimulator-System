package model;


import java.text.ParseException;
import java.util.Collections;
import java.util.List;

public class GraphDrawImpl implements GraphDraw {
  private FlexiUser user;

  @Override
  public void drawGraph(List<Float> values, List<String> timeStamp) throws ParseException {
    System.out.println(values);
    float min = 0;
    float max;
    max = Collections.max(values);
    min = Collections.min(values);
    System.out.println(min);
    double x = max / 50;
    int l = 0;
    x = Math.ceil(x);
    l = (int) x;
    System.out.println(x);
    int m = 0;
    for (int i = 0; i < values.size(); i++) {
      System.out.print(timeStamp.get(i) + "  ");
      m = values.get(i).intValue() / l;
      for (int j = 0; j < m; j++) {
        System.out.print("*");
      }
      System.out.println();
    }

  }
}


