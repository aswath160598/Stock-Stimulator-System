package model;

import org.xml.sax.SAXException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

public interface FlexiUser {

  void addNewFlexiPortfolio(Map<String, List<List<String>>> p, String name);

  float getFlexiPortfolioValue(String fName, String date)
          throws ParseException;

  int getNoOfPortfolios();

  FlexiPortfolio getPortfolio(String portfolioName);

  Boolean checkPortfolioExists(String name);

  List<String> getAllPortfolioNames();

  Boolean checkPortfolioFileExists(String name);

  void addStockToExistingPortfolio(FlexiStocks s, String portfolioName);

  float calculateCostBasis(String portfolioName, String date) throws ParseException;

  void saveFlexiPortfolio(String portfolioName) throws ParserConfigurationException,
          FileNotFoundException, TransformerException;

  void loadFlexiPortfolio(String portfolioName) throws IllegalArgumentException,
          ParserConfigurationException, IOException, SAXException;

  void drawGraph(String fPortfolio, String startDate, String endDate) throws ParseException;
}
