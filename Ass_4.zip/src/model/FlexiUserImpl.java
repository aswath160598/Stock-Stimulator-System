package model;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import static java.time.temporal.ChronoUnit.DAYS;

public class FlexiUserImpl extends UserImpl implements FlexiUser {
  private final Map<String, FlexiPortfolio> fPortfolios;
  private final float commissionFee;

  public FlexiUserImpl() {
    this.fPortfolios = new HashMap<>();
    this.commissionFee = 1;
  }

  public FlexiUserImpl(Map<String, FlexiPortfolio> fportfolios) {
    this.fPortfolios = fportfolios;
    this.commissionFee = 1;
  }

  @Override
  public void addNewFlexiPortfolio(Map<String, List<List<String>>> p, String name) {
    fPortfolios.put(name, new FlexiPortfolioImpl(p));
  }

  @Override
  public int getNoOfPortfolios() {
    return fPortfolios.size();
  }

  @Override
  public FlexiPortfolio getPortfolio(String portfolioName) {
    return this.fPortfolios.get(portfolioName);
  }

  @Override
  public String toString() {
    return this.fPortfolios.toString();
  }

  @Override
  public float getFlexiPortfolioValue(String portfolioName, String date)
          throws ParseException {
    FlexiPortfolio flexiPortfolio = getPortfolio(portfolioName);
    GetStockValueAPIImpl getVal = new GetStockValueAPIImpl();
    String[] buyDate = date.split("-");
    LocalDate buyDateL = LocalDate.of(Integer.parseInt(buyDate[0]),
            Integer.parseInt(buyDate[1]), Integer.parseInt(buyDate[2]));
    Map<String, Float> composition = flexiPortfolio.getComposition(buyDateL);
    float stockValue;
    float sum = 0;
    for (Map.Entry<String, Float> mapElement : composition.entrySet()) {
      String key = mapElement.getKey();
      float noOfShares = mapElement.getValue();
      stockValue = getVal.getStockPrice(key, date);
      sum = sum + (stockValue * noOfShares);
    }
    return sum;
  }

  @Override
  public Boolean checkPortfolioExists(String name) {
    return fPortfolios.containsKey(name);
  }

  @Override
  public List<String> getAllPortfolioNames() {
    List<String> s = new ArrayList<>();
    for (Map.Entry<String, FlexiPortfolio> mapElement : fPortfolios.entrySet()) {
      s.add(mapElement.getKey());
    }
    return s;
  }

  @Override
  public Boolean checkPortfolioFileExists(String name) {
    Path path = Paths.get(name + ".xml");
    return Files.exists(path);
  }

  @Override
  public void addStockToExistingPortfolio(FlexiStocks s, String portfolioName) {
    getPortfolio(portfolioName).addStock(s);
  }

  @Override
  public float calculateCostBasis(String portfolioName, String date) throws ParseException {
    if (checkPortfolioExists(portfolioName)) {
      FlexiPortfolio fp = getPortfolio(portfolioName);
      return fp.calculatePortfolioCostBasis(commissionFee, date);
    } else {
      return 0;
    }
  }

  @Override
  public void saveFlexiPortfolio(String portfolioName) throws ParserConfigurationException,
          FileNotFoundException, TransformerException {
    FlexiPortfolio p = fPortfolios.get(portfolioName);
    FlexiPortfolio fp = getPortfolio(portfolioName);
    FlexiStocks fStocks;
    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

    Document doc = docBuilder.newDocument();
    Element rootElement = doc.createElement("Portfolio");
    rootElement.setAttribute("type", "Flexible");
    doc.appendChild(rootElement);
    int x = 0;
    for (int i = 0; i < fp.size(); i++) {
      fStocks = (fp.getAt(i));
      String tickerSymbol = fStocks.getTicker();
      float noOfShares = fStocks.getNoOfShares();
      String date = fStocks.getBuyDate().toString();
      String s = fStocks.getStatus();
      Element stock = doc.createElement("Stock");
      rootElement.appendChild(stock);
      stock.setAttribute("id", String.valueOf(x));
      x++;
      Element ticker = doc.createElement("Ticker");
      ticker.setTextContent(tickerSymbol);
      stock.appendChild(ticker);

      Element noOfStocks = doc.createElement("NoOfStocks");
      noOfStocks.setTextContent(String.valueOf((int) noOfShares));
      stock.appendChild(noOfStocks);

      Element stockDate = doc.createElement("TransactionDate");
      stockDate.setTextContent(date);
      stock.appendChild(stockDate);

      Element status = doc.createElement("Status");
      status.setTextContent(s);
      stock.appendChild(status);
    }
    FileOutputStream output = new FileOutputStream(portfolioName + ".xml");
    writeXml(doc, output);
  }

  private static void writeXml(Document doc, OutputStream output)
          throws TransformerException {

    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    DOMSource source = new DOMSource(doc);
    StreamResult result = new StreamResult(output);
    transformer.transform(source, result);
  }

  @Override
  public void loadFlexiPortfolio(String portfolioName) throws IllegalArgumentException,
          ParserConfigurationException, IOException, SAXException {
    TickerValidator tv = new TickerValidatorImpl("stock_master_file.csv");
    tv.readFile();
    Map<String, List<List<String>>> h = new HashMap<>();
    File file = new File(portfolioName + ".xml");
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    Document doc = db.parse(file);
    doc.getDocumentElement().normalize();
    NodeList nodeList = doc.getElementsByTagName("Stock");
    for (int itr = 0; itr < nodeList.getLength(); itr++) {
      Node node = nodeList.item(itr);
      if (node.getNodeType() == Node.ELEMENT_NODE) {
        Element eElement = (Element) node;
        String ticker = eElement.getElementsByTagName("Ticker").item(0).getTextContent();
        String noOfStocks = eElement.getElementsByTagName("NoOfStocks")
                .item(0).getTextContent();
        String dateTransaction = eElement.getElementsByTagName("TransactionDate")
                .item(0).getTextContent();
        String status = eElement.getElementsByTagName("Status")
                .item(0).getTextContent();

        if (!(status.equals("b") || status.equals("s"))) {
          throw new IllegalArgumentException("Invalid transaction status in portfolio file.");
        }


        try {
          int nos = Integer.parseInt(noOfStocks);
        } catch (NumberFormatException e) {
          throw new ParserConfigurationException("Invalid no. of shares in file.");
        }


        List<String> val_string = new ArrayList<>();
        val_string.add(dateTransaction);
        val_string.add(status);
        val_string.add(noOfStocks);

        if (!tv.checkTicker(ticker)) {
          throw new IllegalArgumentException("Invalid ticker in file.");
        }

        if (!h.containsKey(ticker)) {
          List<List<String>> s1 = new ArrayList<>();
          s1.add(val_string);
          h.put(ticker, s1);
        } else {
          h.get(ticker).add(val_string);
        }
      }
    }
    addNewFlexiPortfolio(h, portfolioName);
  }

  @Override
  public void drawGraph(String fPortfolio, String startDate, String endDate) throws ParseException {
    GraphDraw gr = new GraphDrawImpl();
    String[] sDateString = startDate.split("-");
    String[] eDateString = endDate.split("-");
    float sum = 0;
    List<String> timeStamp = new ArrayList<>();
    LocalDate sDate1 = LocalDate.of(Integer.parseInt(sDateString[0]),
            Integer.parseInt(sDateString[1]), Integer.parseInt(sDateString[2]));
    LocalDate eDate1 = LocalDate.of(Integer.parseInt(eDateString[0]),
            Integer.parseInt(eDateString[1]), Integer.parseInt(eDateString[2]));
    LocalDate current = sDate1;
    long daysBetween = DAYS.between(sDate1, eDate1);
    List<Float> values = new ArrayList<Float>();
    if (daysBetween > 5 && daysBetween < 31) {
      while (current.isBefore(eDate1) || current.isEqual(eDate1)) {
        sum = 0;
        timeStamp.add(current.toString());
        sum = getFlexiPortfolioValue(fPortfolio, current.toString());
        values.add(sum);
        current = current.plusDays(1);
      }
    } else if (daysBetween > 31 && daysBetween < 60) {
      while (current.isBefore(eDate1) || current.isEqual(eDate1)) {
        sum = 0;
        timeStamp.add(current.toString());
        if(eDate1.isBefore(current))
        {
          current = eDate1;
        }
        sum = getFlexiPortfolioValue(fPortfolio, current.toString());
        values.add(sum);
        current = current.plusDays(2);
      }
    }
    else if (daysBetween > 59 && daysBetween < 150) {
      while (current.isBefore(eDate1) || current.isEqual(eDate1)) {
        sum = 0;
        timeStamp.add(current.toString());
        if(eDate1.isBefore(current))
        {
          current = eDate1;
        }
        sum = getFlexiPortfolioValue(fPortfolio, current.toString());
        values.add(sum);
        current = current.plusDays(5);
      }
    }
    else if (daysBetween>149 && daysBetween<900) {
      while (current.isBefore(eDate1)) {
        sum = 0;
        Month x = current.getMonth();
        String s = String.valueOf(x);
        String sub_str = (s.substring(0, 3));
        String monthYear;
        monthYear = (sub_str + " " + current.getYear());
        timeStamp.add(monthYear);
        LocalDate lastDayOfMonth = LocalDate.parse(current.toString(), DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                .with(TemporalAdjusters.lastDayOfMonth());
        if(eDate1.isBefore(lastDayOfMonth))
        {
          lastDayOfMonth = eDate1;
        }
        sum = getFlexiPortfolioValue(fPortfolio, lastDayOfMonth.toString());
        values.add(sum);
        current = current.plusDays(30);
      }
    }
    else if (daysBetween>899 && daysBetween<2700) {
      while (current.isBefore(eDate1)) {
        sum = 0;
        Month x = current.getMonth();
        String s = String.valueOf(x);
        String sub_str = (s.substring(0, 3));
        String monthYear;
        monthYear = (sub_str + " " + current.getYear());
        timeStamp.add(monthYear);
        LocalDate lastDayOfMonth = LocalDate.parse(current.toString(), DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                .with(TemporalAdjusters.lastDayOfMonth());
        if(eDate1.isBefore(lastDayOfMonth))
        {
          lastDayOfMonth = eDate1;
        }
        sum = getFlexiPortfolioValue(fPortfolio, lastDayOfMonth.toString());
        values.add(sum);
        current = current.plusDays(90);
      }
    }
    else if(daysBetween>2699) {
      while (current.isBefore(eDate1)) {
        int year = current.getYear();
        LocalDate lastWorkingDay = LocalDate.of(year, 12, 31);
        if(eDate1.isBefore(lastWorkingDay))
        {
          lastWorkingDay = eDate1;
        }
        timeStamp.add(lastWorkingDay.toString());
        sum = getFlexiPortfolioValue(fPortfolio, lastWorkingDay.toString());
        values.add(sum);
        current = current.plusDays(365);
      }
    }
    gr.drawGraph(values, timeStamp );
  }


}
