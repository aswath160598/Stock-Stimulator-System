package model;

import java.time.LocalDate;

public interface FlexiStocks extends Stocks{
  abstract LocalDate getBuyDate();

  String getStatus();
}
