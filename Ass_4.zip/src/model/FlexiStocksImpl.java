package model;

import java.time.LocalDate;

public class FlexiStocksImpl extends StocksImpl implements FlexiStocks {
  private final float noOfShares;
  private final float costPrice;
  private final String ticker;
  private final LocalDate buyDate;
  private final String status;

  /**
   * Constructor to initialize a Stock object.
   *
   * @param noOfShares the number of shares
   * @param costPrice  the cost price
   * @param ticker     the ticker symbol
   * @param date       buy date of the stock
   * @param status     of the transaction (b/s)
   */
  public FlexiStocksImpl(float noOfShares, float costPrice,
                         String ticker, LocalDate date, String status) {
    this.noOfShares = noOfShares;
    this.costPrice = costPrice;
    this.ticker = ticker;
    this.buyDate = date;
    this.status = status;
  }

  public FlexiStocksImpl() {
    this.noOfShares = 0;
    this.costPrice = 0;
    this.ticker = null;
    this.buyDate = null;
    this.status = "";
  }

  public static FlexiStocksImplCreator getBuilder1() {
    return new FlexiStocksImplCreator();
  }

  @Override
  public String getTicker() {
    return this.ticker;
  }

  @Override
  public float getNoOfShares() {
    return this.noOfShares;
  }

  @Override
  public float getCostPrice() {
    return this.costPrice;
  }

  @Override
  public LocalDate getBuyDate() {
    return this.buyDate;
  }

  @Override
  public String getStatus() {
    return this.status;
  }

  @Override
  public String toString() {
//    if (this.buyDate != null) {
//      return this.ticker + " " + (int) this.noOfShares + " " + this.buyDate;
//    } else {
//      return this.ticker + " " + (int) this.noOfShares;
//    }
    return this.ticker + " " + (int) this.noOfShares + " " + this.status + " " + this.buyDate;

  }

  /**
   * Static Class  of the Stock Implementation Creator that uses the builder Design.
   */
  public static class FlexiStocksImplCreator {
    private float noOfShares;
    private float costPrice;
    private String ticker;
    private LocalDate buyDate;
    private String status;

    private FlexiStocksImplCreator() {
      this.noOfShares = 0;
      this.costPrice = 0;
      this.ticker = null;
      this.buyDate = null;
    }

    /**
     * Created a Stock.
     *
     * @return the stock object
     */
    public FlexiStocks create() {
      return new FlexiStocksImpl(noOfShares, costPrice, ticker, buyDate, status);
    }

    /**
     * Stock Creator to check valid number of stocks.
     *
     * @param ns number of shares
     * @return the number of shares returned
     */
    public FlexiStocksImplCreator noOfShares(float ns) {
      if (ns <= 0) {
        throw new IllegalArgumentException("Invalid number of shares entered");
      }
      this.noOfShares = ns;
      return this;
    }

    /**
     * Stock Creator to check valid number of shares.
     *
     * @param cp the cost price
     * @return the number of shares returned
     */
    public FlexiStocksImplCreator costPrice(float cp) {
      if (cp <= 0) {
        throw new IllegalArgumentException("Invalid number of shares entered");
      }
      this.costPrice = cp;
      return this;
    }

    /**
     * Stock Creator to check valid number of shares.
     *
     * @param t ticker symbol
     * @return the ticker symbol
     */
    public FlexiStocksImplCreator ticker(String t) {
      if (t == null || t.equals("")) {
        throw new IllegalArgumentException("Invalid ticker entered");
      }
      this.ticker = t;
      return this;
    }

    public FlexiStocksImplCreator buyDate(LocalDate date) {
//      String[] dSplit = d.split("-");
//      LocalDate date = LocalDate.of(Integer.parseInt(dSplit[0]),
//              Integer.parseInt(dSplit[1]), Integer.parseInt(dSplit[2]));
      if (date.isAfter(LocalDate.now())) {
        throw new IllegalArgumentException("Date cannot be in the future.");
      }
      this.buyDate = date;
      return this;
    }

    public FlexiStocksImplCreator status(String status) {
      this.status = status;
      return this;
    }
  }
}
