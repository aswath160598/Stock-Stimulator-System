package model;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * This class represents the API computations where the stock value is returned on a specific date.
 */
public class GetStockValueAPIImpl implements GetStockValueAPI {
  @Override
  public float getStockPrice(String ticker, String sDate1) throws ParseException {
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Date myDate = dateFormat.parse(sDate1);
    Date oneDayBefore;
    Date twoDayBefore;
    String apiKey = "MOIOJBEOTYOYQLVI";
    String stockSymbol = ticker; //ticker symbol for Google
    URL url = null;

    try {
      url = new URL("https://www.alphavantage"
              + ".co/query?function=TIME_SERIES_DAILY"
              + "&outputsize=full"
              + "&symbol"
              + "=" + stockSymbol + "&apikey=" + apiKey + "&datatype=csv");
    } catch (MalformedURLException e) {
      throw new RuntimeException("the alphavantage API has either changed or "
              + "no longer works");
    }

    InputStream in = null;
    StringBuilder output = new StringBuilder();

    try {
      in = url.openStream();
      int b;

      while ((b = in.read()) != -1) {
        output.append((char) b);
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("No price data found for " + stockSymbol);
    }
    List<String> ticker1 = new ArrayList<>();
    List<Float> intArray = new ArrayList<>();
    String outputString = output.toString();
    String[] lines = outputString.split("\\r?\\n");
    for (int i = 1; i < lines.length; i++) {
      String[] s = lines[i].split(",");
      ticker1.add(s[0]);
      intArray.add(Float.valueOf(s[4]));
    }
    if (!ticker1.contains(sDate1)) {
      oneDayBefore = new Date(myDate.getTime() - 1);
      sDate1 = (dateFormat.format(oneDayBefore));
      oneDayBefore = dateFormat.parse(sDate1);
      if (!ticker1.contains(sDate1)) {
        twoDayBefore = new Date(oneDayBefore.getTime() - 2);
        sDate1 = (dateFormat.format(twoDayBefore));
      }
    }
    int x = ticker1.indexOf(sDate1);
    float value = intArray.get(x);
    BigDecimal salary3 = new BigDecimal(value).setScale(2, RoundingMode.HALF_UP);
    float r = Float.parseFloat(String.valueOf(salary3));
    return r;
  }
}
