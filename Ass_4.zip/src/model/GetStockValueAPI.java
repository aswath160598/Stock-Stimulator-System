package model;

import java.text.ParseException;

/**
 * The Interface represents the method to get each Stock value inside a Portfolio.
 */
public interface GetStockValueAPI {
  /**
   * Function get the stock values from the API.
   * @param ticker ticker symbol of each Stock.
   * @param date   date on which the Stock value should be computed.
   * @return the Stock price on that day.
   * @throws ParseException throws this exception if there are issues with parsing.
   */
  float getStockPrice(String ticker, String date) throws ParseException;
}
