package model;

import java.text.ParseException;
import java.util.List;

public interface GraphDraw {
  void drawGraph(List<Float> values, List<String> timeStamp) throws ParseException;
}
