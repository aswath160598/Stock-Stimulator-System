import org.junit.Test;

import java.time.LocalDate;

import static org.junit.Assert.assertEquals;

public class DollarCostAveragingImplTest {
  @Test
  public void test1() {
    LocalDate d = LocalDate.of(2020, 1, 1);
    LocalDate d1 = LocalDate.of(2022, 10, 10);
//    DollarCostAveraging abc = new DollarCostAveraging("p1", d, d1, 102f, 30);
  }
}
